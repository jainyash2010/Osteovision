# StrideCare local model card

Version: `stridecare-local-2.0`  
Artifact seed: `20260320`  
Artifacts: `src/lib/models/weights.json`, `src/lib/models/report.json`

No external AI API, cloud inference endpoint, or pretrained third-party model is used. Both models are trained, tested, and executed locally from weights checked into the project. Assessment persistence uses Next.js server actions rather than REST API calls; the only HTTP route is the platform healthcheck.

## Model 1 — Logistic OA screening classifier

- Input: 10 standardised features: age, BMI, pain, morning stiffness, prior injury, family history, low activity, reduced knee flexion, left/right asymmetry, alignment deviation.
- Training: 3,200 synthetic intake records; batch gradient descent, 320 epochs, L2 regularisation, learned feature mean/scale.
- Output: probability of the elevated-marker class, converted to a 0–100 screening score with temperature calibration.
- Held-out test: 800 records, deterministic 80/20 split.
- Test results: accuracy **0.930**, precision **0.929**, recall **0.908**, F1 **0.918**, ROC-AUC **0.943**.
- Rule-based explanations and cautions in the UI are separate from the learned numerical score.

## Model 2 — Ridge silhouette-to-keypoint regressor

- Input: a 48×72 binary silhouette extracted by row-wise border-background subtraction; 40 features from bounding box plus 12 vertical-band density, centre and width statistics.
- Training: 720 synthetic full-body gait silhouettes with known hip, knee and ankle coordinates.
- Fit: closed-form ridge normal equations for 12 coordinate outputs (6 keypoints × x/y), including a bias term and an anatomical-prior blend at inference.
- Held-out test: 180 unseen synthetic poses.
- Test results: mean **1.07 px** landmark error; mean normalised error **0.018**. Per-keypoint errors range from **0.76 px** (hips) to **1.50 px** (ankles).

## Reproduce training and tests

```bash
npx tsx scripts/train-models.ts
npx tsx scripts/test-models.ts
```

Environment overrides: `MODEL_SEED`, `RISK_SAMPLES`, `LANDMARK_SAMPLES`.

The `/models` page can also retrain and retest both models entirely in the browser with a fresh seed, display the confusion matrix and loss curve, and run a visual inference test on the sample walking frame.

## Validation boundary

The training and test data are deterministic **synthetic** data generated for software verification. These metrics are not clinical validation. The landmark model is an approximate seed for manual refinement, and the risk model is screening support only — not a diagnosis. Real deployment requires prospective patient data, ethics review, regulatory assessment, and clinical validation.
