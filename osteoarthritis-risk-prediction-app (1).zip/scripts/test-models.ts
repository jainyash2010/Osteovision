import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import {
  FEATURE_NAMES,
  MASK_BANDS,
  inferLandmarkTargets,
  predictRiskProbability,
  riskScoreFromProbability,
} from "../src/lib/ml-core";
import type { ModelReport, ModelWeights } from "../src/lib/ml-core";
import type { ClinicalProfile, Metrics } from "../src/lib/types";

const directory = path.join(process.cwd(), "src", "lib", "models");
const weights = JSON.parse(readFileSync(path.join(directory, "weights.json"), "utf8")) as ModelWeights;
const report = JSON.parse(readFileSync(path.join(directory, "report.json"), "utf8")) as ModelReport;

assert.equal(weights.version, report.version, "Weights and report versions must match");
assert.equal(weights.seed, report.seed, "Weights and report seeds must match");
assert.equal(weights.risk.featureNames.length, FEATURE_NAMES.length);
assert.equal(weights.risk.weights.length, FEATURE_NAMES.length);
assert.equal(weights.risk.mean.length, FEATURE_NAMES.length);
assert.equal(weights.risk.scale.length, FEATURE_NAMES.length);
assert.ok(weights.risk.scale.every((value) => Number.isFinite(value) && value > 0), "Feature scales must be positive");
assert.ok(weights.risk.weights.every(Number.isFinite), "Risk weights must be finite");
assert.ok(weights.risk.temperature > 1, "Risk score must be temperature calibrated");
assert.equal(weights.landmarks.outputs.length, 12, "Six keypoints need twelve regression outputs");
assert.equal(weights.landmarks.bands, MASK_BANDS);
assert.equal(weights.landmarks.featureCount, 40);
assert.ok(weights.landmarks.outputs.every((row) => row.length === 41 && row.every(Number.isFinite)), "Landmark coefficients must be finite");

assert.equal(report.risk.trainSize + report.risk.testSize, 4000);
assert.equal(report.landmarks.trainSize + report.landmarks.testSize, 900);
assert.ok(report.risk.testSize > 0 && report.landmarks.testSize > 0, "Held-out test sets must exist");
assert.ok(report.risk.accuracy >= 0.85, `Risk accuracy too low: ${report.risk.accuracy}`);
assert.ok(report.risk.rocAuc >= 0.88, `Risk ROC-AUC too low: ${report.risk.rocAuc}`);
assert.ok(report.risk.lossCurve[0] > report.risk.lossCurve.at(-1)!, "Training loss must decrease");
assert.ok(report.landmarks.meanPixelError < 3, `Landmark test error too high: ${report.landmarks.meanPixelError}`);
assert.ok(Object.values(report.landmarks.perKeypointPixelError).every((value) => value < 4), "Every keypoint must meet the test threshold");

const baseMetrics: Metrics = {
  leftFlexion: 5.1,
  rightFlexion: 17.6,
  avgFlexion: 11.4,
  asymmetry: 12.5,
  alignmentDeviation: 0.049,
  strideSpread: 0.704,
  gaitConfidence: 100,
  keypointCount: 6,
  aspectRatio: 1.5,
};
const lowProfile: ClinicalProfile = {
  name: "low", age: 36, sex: "female", heightCm: 168, weightKg: 61, painLevel: 1,
  morningStiffness: false, priorInjury: false, familyHistory: false, activityLevel: "high", notes: "",
};
const highProfile: ClinicalProfile = {
  name: "high", age: 68, sex: "female", heightCm: 158, weightKg: 81, painLevel: 7,
  morningStiffness: true, priorInjury: true, familyHistory: true, activityLevel: "low", notes: "",
};

const lowProbability = predictRiskProbability(lowProfile, baseMetrics, weights.risk);
const highProbability = predictRiskProbability(highProfile, baseMetrics, weights.risk);
const lowScore = riskScoreFromProbability(lowProbability, weights.risk);
const highScore = riskScoreFromProbability(highProbability, weights.risk);
assert.equal(lowProbability, predictRiskProbability(lowProfile, baseMetrics, weights.risk), "Inference must be deterministic");
assert.ok(highProbability > lowProbability, "Higher-risk profile must produce higher predicted probability");
assert.ok(highScore >= 60 && lowScore < 30, `Calibration failed: low=${lowScore} high=${highScore}`);

const zeroFeatures = Array.from({ length: weights.landmarks.featureCount }, () => 0);
const targets = inferLandmarkTargets(zeroFeatures, weights.landmarks);
assert.equal(targets.length, 12);
assert.ok(targets.every((value) => Number.isFinite(value) && value >= 0 && value <= 1), "Landmark outputs must be normalised");

console.log("✓ Local model artifact, training, held-out test, calibration and inference checks passed");
console.log(`  risk: accuracy=${report.risk.accuracy}, ROC-AUC=${report.risk.rocAuc}, F1=${report.risk.f1}`);
console.log(`  landmarks: mean pixel error=${report.landmarks.meanPixelError}px on held-out silhouettes`);
console.log(`  calibration: low=${lowScore}, high=${highScore}`);
