import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import {
  buildRiskFeatures,
  predictRiskProbability,
  riskScoreFromProbability,
  trainAndTestModels,
} from "../src/lib/ml-core";
import type { ClinicalProfile, Metrics } from "../src/lib/types";

const seed = Number(process.env.MODEL_SEED ?? 20260320);
const riskSamples = Number(process.env.RISK_SAMPLES ?? 4000);
const landmarkSamples = Number(process.env.LANDMARK_SAMPLES ?? 900);

const { weights, report } = trainAndTestModels({ seed, riskSamples, landmarkSamples });
const outputDirectory = path.join(process.cwd(), "src", "lib", "models");
mkdirSync(outputDirectory, { recursive: true });
writeFileSync(path.join(outputDirectory, "weights.json"), `${JSON.stringify(weights, null, 2)}\n`);
writeFileSync(path.join(outputDirectory, "report.json"), `${JSON.stringify(report, null, 2)}\n`);

// Sanity-check calibration against the four profile archetypes used in the demo data.
const baseMetrics: Metrics = {
  leftFlexion: 5.1,
  rightFlexion: 17.6,
  avgFlexion: 11.4,
  asymmetry: 12.5,
  alignmentDeviation: 0.049,
  strideSpread: 0.704,
  gaitConfidence: 100,
  keypointCount: 6,
  aspectRatio: 1.5,
};
const archetypes: Array<[string, ClinicalProfile]> = [
  [
    "low-symptom younger",
    { name: "sample", age: 36, sex: "female", heightCm: 168, weightKg: 61, painLevel: 1, morningStiffness: false, priorInjury: false, familyHistory: false, activityLevel: "high", notes: "" },
  ],
  [
    "moderate symptoms",
    { name: "sample", age: 54, sex: "male", heightCm: 174, weightKg: 84, painLevel: 4, morningStiffness: true, priorInjury: false, familyHistory: false, activityLevel: "moderate", notes: "" },
  ],
  [
    "multi-factor high",
    { name: "sample", age: 68, sex: "female", heightCm: 158, weightKg: 81, painLevel: 7, morningStiffness: true, priorInjury: true, familyHistory: true, activityLevel: "low", notes: "" },
  ],
];

console.log(`Trained ${weights.version} with seed ${seed}`);
console.log("Risk model:", JSON.stringify(report.risk));
console.log("Landmark model:", JSON.stringify(report.landmarks));
console.log("Calibration examples:");
for (const [label, profile] of archetypes) {
  const features = buildRiskFeatures(profile, baseMetrics);
  const probability = predictRiskProbability(profile, baseMetrics, weights.risk);
  const score = riskScoreFromProbability(probability, weights.risk);
  console.log(`  ${label}: p=${probability.toFixed(3)} score=${score} features=${features.length}`);
}
