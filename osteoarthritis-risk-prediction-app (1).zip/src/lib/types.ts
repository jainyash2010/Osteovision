export type KeypointKey =
  | "leftHip"
  | "leftKnee"
  | "leftAnkle"
  | "rightHip"
  | "rightKnee"
  | "rightAnkle";

export type Point = { x: number; y: number };
export type Keypoints = Partial<Record<KeypointKey, Point>>;

export const KEYPOINT_ORDER: KeypointKey[] = [
  "leftHip",
  "leftKnee",
  "leftAnkle",
  "rightHip",
  "rightKnee",
  "rightAnkle",
];

export const KEYPOINT_LABELS: Record<KeypointKey, string> = {
  leftHip: "Left hip",
  leftKnee: "Left knee",
  leftAnkle: "Left ankle",
  rightHip: "Right hip",
  rightKnee: "Right knee",
  rightAnkle: "Right ankle",
};

export const KEYPOINT_SHORT: Record<KeypointKey, string> = {
  leftHip: "LH",
  leftKnee: "LK",
  leftAnkle: "LA",
  rightHip: "RH",
  rightKnee: "RK",
  rightAnkle: "RA",
};

export type Sex = "female" | "male" | "other";
export type ActivityLevel = "low" | "moderate" | "high";
export type MediaType = "image" | "video" | "sample";
export type RiskBand = "Low" | "Moderate" | "High";
export type DoctorStatus = "Pending review" | "Reviewed" | "Follow-up";

export type ClinicalProfile = {
  name: string;
  age: number;
  sex: Sex;
  heightCm: number;
  weightKg: number;
  painLevel: number;
  morningStiffness: boolean;
  priorInjury: boolean;
  familyHistory: boolean;
  activityLevel: ActivityLevel;
  notes: string;
};

export type MediaInfo = {
  type: MediaType;
  fileName: string;
  durationSec?: number;
  aspectRatio: number;
  frames: string[];
  selectedFrame: number;
};

export type Metrics = {
  leftFlexion: number;
  rightFlexion: number;
  avgFlexion: number;
  asymmetry: number;
  alignmentDeviation: number;
  strideSpread: number;
  gaitConfidence: number;
  keypointCount: number;
  aspectRatio: number;
};

export type RiskResult = {
  score: number;
  band: RiskBand;
  bmi: number;
  probability?: number;
  drivers: string[];
  recommendations: string[];
  metrics: Metrics;
};

export type AssessmentRecord = {
  id: number;
  patient: ClinicalProfile;
  media: MediaInfo;
  keypoints: Keypoints;
  metrics: Metrics;
  risk: RiskResult;
  score: number;
  band: RiskBand;
  drivers: string[];
  recommendations: string[];
  doctorStatus: DoctorStatus;
  doctorNotes: string;
  createdAt: string;
  reviewedAt: string | null;
};

export type AssessmentPayload = {
  patient: ClinicalProfile;
  media: MediaInfo;
  keypoints: Keypoints;
};

export const DEFAULT_PROFILE: ClinicalProfile = {
  name: "",
  age: 52,
  sex: "female",
  heightCm: 165,
  weightKg: 70,
  painLevel: 3,
  morningStiffness: false,
  priorInjury: false,
  familyHistory: false,
  activityLevel: "moderate",
  notes: "",
};

export const DEMO_KEYPOINTS: Keypoints = {
  leftHip: { x: 0.465, y: 0.455 },
  leftKnee: { x: 0.42, y: 0.665 },
  leftAnkle: { x: 0.39, y: 0.865 },
  rightHip: { x: 0.49, y: 0.455 },
  rightKnee: { x: 0.515, y: 0.645 },
  rightAnkle: { x: 0.59, y: 0.85 },
};

export const DEMO_FRAME = "/images/sample-gait.jpg";
