import {
  KEYPOINT_ORDER,
  type ClinicalProfile,
  type KeypointKey,
  type Keypoints,
  type Metrics,
  type Point,
} from "./types";

export const FEATURE_NAMES = [
  "age",
  "bmi",
  "pain",
  "morningStiffness",
  "priorInjury",
  "familyHistory",
  "lowActivity",
  "reducedFlexion",
  "asymmetry",
  "alignment",
] as const;

export const MASK_WIDTH = 48;
export const MASK_HEIGHT = 72;
export const MASK_BANDS = 12;

export type RiskModel = {
  name: string;
  featureNames: string[];
  mean: number[];
  scale: number[];
  weights: number[];
  bias: number;
  epochs: number;
  learningRate: number;
  l2: number;
  scoreGain: number;
  temperature: number;
};

export type LandmarkModel = {
  name: string;
  width: number;
  height: number;
  bands: number;
  featureCount: number;
  ridge: number;
  outputs: number[][];
};

export type ModelWeights = {
  version: string;
  seed: number;
  risk: RiskModel;
  landmarks: LandmarkModel;
};

export type ConfusionMatrix = { tp: number; fp: number; tn: number; fn: number };

export type ModelReport = {
  version: string;
  seed: number;
  generatedAt: string;
  risk: {
    trainSize: number;
    testSize: number;
    positiveRate: number;
    accuracy: number;
    precision: number;
    recall: number;
    f1: number;
    rocAuc: number;
    confusion: ConfusionMatrix;
    finalLoss: number;
    lossCurve: number[];
    epochs: number;
  };
  landmarks: {
    trainSize: number;
    testSize: number;
    meanPixelError: number;
    meanNormalizedError: number;
    perKeypointPixelError: Record<KeypointKey, number>;
    featureCount: number;
    ridge: number;
  };
  notes: string[];
};

type RiskExample = { features: number[]; label: number };
type LandmarkExample = { features: number[]; targets: number[]; points: Keypoints };
type Split<T> = { train: T[]; test: T[] };

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const sigmoid = (value: number) => 1 / (1 + Math.exp(-clamp(value, -35, 35)));

function mulberry32(seed: number) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function splitExamples<T>(items: T[], rng: () => number, ratio = 0.8): Split<T> {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const cut = Math.floor(shuffled.length * ratio);
  return { train: shuffled.slice(0, cut), test: shuffled.slice(cut) };
}

function bmiFromProfile(profile: ClinicalProfile) {
  const meters = Math.max(profile.heightCm / 100, 0.5);
  return profile.weightKg / (meters * meters);
}

export function buildRiskFeatures(profile: ClinicalProfile, metrics: Metrics): number[] {
  const bmi = bmiFromProfile(profile);
  return [
    (profile.age - 50) / 30,
    (bmi - 25) / 7,
    profile.painLevel / 10,
    profile.morningStiffness ? 1 : 0,
    profile.priorInjury ? 1 : 0,
    profile.familyHistory ? 1 : 0,
    profile.activityLevel === "low" ? 1 : 0,
    clamp((60 - metrics.avgFlexion) / 40, -0.5, 1.5),
    metrics.asymmetry / 20,
    metrics.alignmentDeviation / 0.15,
  ];
}

function generateRiskExamples(count: number, rng: () => number): RiskExample[] {
  // Ground-truth generator for a synthetic screening benchmark. The learner only
  // receives features and noisy binary labels, never these latent coefficients.
  const latentWeights = [0.7, 0.7, 1.2, 0.4, 0.6, 0.3, 0.25, 0.4, 0.3, 0.2];
  const latentIntercept = -1.9;
  const examples: RiskExample[] = [];

  for (let index = 0; index < count; index += 1) {
    const heightCm = 150 + rng() * 40;
    const bmi = 17 + rng() * 23;
    const profile: ClinicalProfile = {
      name: `synthetic-${index}`,
      age: Math.round(18 + rng() * 65),
      sex: rng() < 0.5 ? "female" : "male",
      heightCm,
      weightKg: bmi * (heightCm / 100) ** 2,
      painLevel: Math.floor(rng() * 11),
      morningStiffness: rng() < 0.3,
      priorInjury: rng() < 0.24,
      familyHistory: rng() < 0.3,
      activityLevel: rng() < 0.35 ? "low" : rng() < 0.6 ? "moderate" : "high",
      notes: "",
    };
    const metrics: Metrics = {
      leftFlexion: 0,
      rightFlexion: 0,
      avgFlexion: 15 + rng() * 70,
      asymmetry: rng() * 24,
      alignmentDeviation: rng() * rng() * 0.22,
      strideSpread: 0,
      gaitConfidence: 100,
      keypointCount: 6,
      aspectRatio: 1.5,
    };
    const features = buildRiskFeatures(profile, metrics);
    const z = latentIntercept + features.reduce((sum, value, i) => sum + value * latentWeights[i], 0);
    const deterministicLabel = z >= 0 ? 1 : 0;
    // Keep a realistic amount of annotation noise without overwhelming the signal.
    const label = rng() < 0.06 ? 1 - deterministicLabel : deterministicLabel;
    examples.push({ features, label });
  }
  return examples;
}

function trainRiskModel(examples: RiskExample[], rng: () => number) {
  const { train, test } = splitExamples(examples, rng);
  const dimensions = FEATURE_NAMES.length;
  const mean = Array.from({ length: dimensions }, (_, i) => train.reduce((sum, item) => sum + item.features[i], 0) / train.length);
  const scale = Array.from({ length: dimensions }, (_, i) => {
    const variance = train.reduce((sum, item) => sum + (item.features[i] - mean[i]) ** 2, 0) / train.length;
    return Math.sqrt(variance) || 1;
  });
  const standardizedTrain = train.map((item) => ({
    x: item.features.map((value, i) => (value - mean[i]) / scale[i]),
    y: item.label,
  }));

  const positives = train.reduce((sum, item) => sum + item.label, 0);
  const prevalence = clamp(positives / train.length, 0.01, 0.99);
  let bias = Math.log(prevalence / (1 - prevalence));
  let weights = Array.from({ length: dimensions }, () => 0);
  const epochs = 320;
  const learningRate = 0.42;
  const l2 = 0.002;
  const lossCurve: number[] = [];

  for (let epoch = 0; epoch < epochs; epoch += 1) {
    const gradients = Array.from({ length: dimensions }, () => 0);
    let gradientBias = 0;
    let loss = 0;
    for (const item of standardizedTrain) {
      const probability = sigmoid(bias + weights.reduce((sum, w, i) => sum + w * item.x[i], 0));
      const error = probability - item.y;
      for (let i = 0; i < dimensions; i += 1) gradients[i] += error * item.x[i];
      gradientBias += error;
      loss += -(item.y * Math.log(probability + 1e-9) + (1 - item.y) * Math.log(1 - probability + 1e-9));
    }
    const rate = learningRate / (1 + epoch * 0.006);
    for (let i = 0; i < dimensions; i += 1) {
      weights[i] -= rate * (gradients[i] / standardizedTrain.length + l2 * weights[i]);
    }
    bias -= rate * (gradientBias / standardizedTrain.length);
    if (epoch % 20 === 0 || epoch === epochs - 1) {
      lossCurve.push(Math.round((loss / standardizedTrain.length) * 10000) / 10000);
    }
  }

  const model: RiskModel = {
    name: "Local logistic OA screening classifier",
    featureNames: [...FEATURE_NAMES],
    mean,
    scale,
    weights,
    bias,
    epochs,
    learningRate,
    l2,
    scoreGain: 1,
    temperature: 1.8,
  };
  return { model, train, test, lossCurve, finalLoss: lossCurve[lossCurve.length - 1] ?? 0 };
}

function standardizedProbability(features: number[], model: RiskModel) {
  const x = features.map((value, i) => (value - model.mean[i]) / (model.scale[i] || 1));
  return sigmoid(model.bias + x.reduce((sum, value, i) => sum + value * model.weights[i], 0));
}

export function predictRiskProbability(profile: ClinicalProfile, metrics: Metrics, model: RiskModel) {
  return standardizedProbability(buildRiskFeatures(profile, metrics), model);
}

export function riskScoreFromProbability(probability: number, model: RiskModel) {
  const safeProbability = clamp(probability, 0.001, 0.999);
  const logit = Math.log(safeProbability / (1 - safeProbability));
  const calibrated = sigmoid(logit / Math.max(0.1, model.temperature));
  return clamp(Math.round(calibrated * model.scoreGain * 100), 0, 100);
}

function evaluateClassifier(model: RiskModel, test: RiskExample[]) {
  const scored = test.map((item) => ({ label: item.label, score: standardizedProbability(item.features, model) }));
  const confusion: ConfusionMatrix = { tp: 0, fp: 0, tn: 0, fn: 0 };
  for (const item of scored) {
    const predicted = item.score >= 0.5 ? 1 : 0;
    if (predicted === 1 && item.label === 1) confusion.tp += 1;
    else if (predicted === 1) confusion.fp += 1;
    else if (item.label === 0) confusion.tn += 1;
    else confusion.fn += 1;
  }
  const accuracy = (confusion.tp + confusion.tn) / Math.max(test.length, 1);
  const precision = confusion.tp / Math.max(confusion.tp + confusion.fp, 1);
  const recall = confusion.tp / Math.max(confusion.tp + confusion.fn, 1);
  const f1 = (2 * precision * recall) / Math.max(precision + recall, 1e-9);
  const sorted = [...scored].sort((a, b) => a.score - b.score);
  const positives = scored.filter((item) => item.label === 1).length;
  const negatives = scored.length - positives;
  let positiveRankSum = 0;
  sorted.forEach((item, index) => {
    if (item.label === 1) positiveRankSum += index + 1;
  });
  const rocAuc = positives && negatives
    ? (positiveRankSum - (positives * (positives + 1)) / 2) / (positives * negatives)
    : 0.5;
  return { accuracy, precision, recall, f1, rocAuc, confusion };
}

function setMaskPixel(mask: Uint8Array, x: number, y: number) {
  if (x >= 0 && x < MASK_WIDTH && y >= 0 && y < MASK_HEIGHT) mask[y * MASK_WIDTH + x] = 1;
}

function drawDisk(mask: Uint8Array, cx: number, cy: number, radius: number) {
  for (let y = Math.floor(cy - radius); y <= Math.ceil(cy + radius); y += 1) {
    for (let x = Math.floor(cx - radius); x <= Math.ceil(cx + radius); x += 1) {
      if ((x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2) setMaskPixel(mask, x, y);
    }
  }
}

function drawSegment(mask: Uint8Array, from: Point, to: Point, radius: number) {
  const x1 = from.x * (MASK_WIDTH - 1);
  const y1 = from.y * (MASK_HEIGHT - 1);
  const x2 = to.x * (MASK_WIDTH - 1);
  const y2 = to.y * (MASK_HEIGHT - 1);
  const steps = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) * 1.6));
  for (let step = 0; step <= steps; step += 1) {
    const t = step / steps;
    drawDisk(mask, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, radius);
  }
}

export function extractMaskFeatures(mask: Uint8Array, width = MASK_WIDTH, height = MASK_HEIGHT, bands = MASK_BANDS) {
  let minX = width;
  let maxX = -1;
  let minY = height;
  let maxY = -1;
  let foreground = 0;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (mask[y * width + x]) {
        foreground += 1;
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
    }
  }
  if (maxX < 0) {
    return { features: Array(4 + bands * 3).fill(0), foregroundCoverage: 0, bbox: [0, 0, 0, 0] };
  }

  const features = [
    minX / (width - 1),
    minY / (height - 1),
    (maxX - minX) / (width - 1),
    (maxY - minY) / (height - 1),
  ];
  const rowsPerBand = height / bands;
  for (let band = 0; band < bands; band += 1) {
    const start = Math.floor(band * rowsPerBand);
    const end = Math.min(height, Math.ceil((band + 1) * rowsPerBand));
    let count = 0;
    let sumX = 0;
    let bandMinX = width;
    let bandMaxX = -1;
    for (let y = start; y < end; y += 1) {
      for (let x = 0; x < width; x += 1) {
        if (mask[y * width + x]) {
          count += 1;
          sumX += x;
          bandMinX = Math.min(bandMinX, x);
          bandMaxX = Math.max(bandMaxX, x);
        }
      }
    }
    features.push(count / Math.max(1, (end - start) * width));
    features.push(count ? sumX / count / (width - 1) : (minX + maxX) / 2 / (width - 1));
    features.push(count ? (bandMaxX - bandMinX) / (width - 1) : 0);
  }
  return {
    features,
    foregroundCoverage: foreground / (width * height),
    bbox: [minX / (width - 1), minY / (height - 1), (maxX - minX) / (width - 1), (maxY - minY) / (height - 1)],
  };
}

function generateLandmarkExamples(count: number, rng: () => number): LandmarkExample[] {
  const examples: LandmarkExample[] = [];
  for (let index = 0; index < count; index += 1) {
    const mask = new Uint8Array(MASK_WIDTH * MASK_HEIGHT);
    const centerX = 0.5 + (rng() - 0.5) * 0.12;
    const hipY = 0.42 + rng() * 0.06;
    const hipWidth = 0.06 + rng() * 0.025;
    const upper = 0.17 + rng() * 0.035;
    const lower = 0.2 + rng() * 0.04;
    const phase = rng() * Math.PI * 2;
    const leftUpperAngle = Math.sin(phase) * 0.5 + (rng() - 0.5) * 0.12;
    const rightUpperAngle = -Math.sin(phase) * 0.5 + (rng() - 0.5) * 0.12;
    const leftLowerAngle = leftUpperAngle + 0.1 + rng() * 0.55;
    const rightLowerAngle = rightUpperAngle - 0.1 - rng() * 0.55;
    const xScale = 0.64;

    const leftHip = { x: centerX - hipWidth / 2, y: hipY };
    const rightHip = { x: centerX + hipWidth / 2, y: hipY };
    const leftKnee = {
      x: leftHip.x + Math.sin(leftUpperAngle) * upper * xScale,
      y: leftHip.y + Math.cos(leftUpperAngle) * upper,
    };
    const rightKnee = {
      x: rightHip.x + Math.sin(rightUpperAngle) * upper * xScale,
      y: rightHip.y + Math.cos(rightUpperAngle) * upper,
    };
    const leftAnkle = {
      x: leftKnee.x + Math.sin(leftLowerAngle) * lower * xScale,
      y: leftKnee.y + Math.cos(leftLowerAngle) * lower,
    };
    const rightAnkle = {
      x: rightKnee.x + Math.sin(rightLowerAngle) * lower * xScale,
      y: rightKnee.y + Math.cos(rightLowerAngle) * lower,
    };
    const points: Keypoints = { leftHip, leftKnee, leftAnkle, rightHip, rightKnee, rightAnkle };

    const shoulderY = hipY - 0.22;
    const leftShoulder = { x: centerX - 0.075, y: shoulderY };
    const rightShoulder = { x: centerX + 0.075, y: shoulderY };
    const leftHand = {
      x: leftShoulder.x + Math.sin(phase + Math.PI) * 0.1,
      y: shoulderY + 0.18 + rng() * 0.04,
    };
    const rightHand = {
      x: rightShoulder.x + Math.sin(phase) * 0.1,
      y: shoulderY + 0.18 + rng() * 0.04,
    };
    const neck = { x: centerX, y: shoulderY - 0.02 };
    const head = { x: centerX, y: shoulderY - 0.065 };

    drawSegment(mask, { x: centerX, y: hipY }, neck, 3.6);
    drawSegment(mask, leftShoulder, rightShoulder, 2.8);
    drawSegment(mask, leftHip, rightHip, 2.8);
    drawSegment(mask, leftShoulder, leftHand, 2.1);
    drawSegment(mask, rightShoulder, rightHand, 2.1);
    drawSegment(mask, leftHip, leftKnee, 2.7);
    drawSegment(mask, leftKnee, leftAnkle, 2.2);
    drawSegment(mask, rightHip, rightKnee, 2.7);
    drawSegment(mask, rightKnee, rightAnkle, 2.2);
    drawSegment(mask, leftAnkle, { x: leftAnkle.x + 0.035, y: leftAnkle.y + 0.008 }, 1.9);
    drawSegment(mask, rightAnkle, { x: rightAnkle.x + 0.035, y: rightAnkle.y + 0.008 }, 1.9);
    drawDisk(mask, head.x * (MASK_WIDTH - 1), head.y * (MASK_HEIGHT - 1), 3.2);

    const { features } = extractMaskFeatures(mask);
    const targets = KEYPOINT_ORDER.flatMap((key) => {
      const point = points[key]!;
      return [point.x, point.y];
    });
    examples.push({ features, targets, points });
  }
  return examples;
}

function solveLinearSystem(matrix: number[][], vector: number[]) {
  const size = vector.length;
  const augmented = matrix.map((row, i) => [...row, vector[i]]);
  for (let column = 0; column < size; column += 1) {
    let pivot = column;
    for (let row = column + 1; row < size; row += 1) {
      if (Math.abs(augmented[row][column]) > Math.abs(augmented[pivot][column])) pivot = row;
    }
    [augmented[column], augmented[pivot]] = [augmented[pivot], augmented[column]];
    const divisor = augmented[column][column] || 1e-9;
    for (let row = column + 1; row < size; row += 1) {
      const factor = augmented[row][column] / divisor;
      if (!factor) continue;
      for (let col = column; col <= size; col += 1) augmented[row][col] -= factor * augmented[column][col];
    }
  }
  const solution = Array.from({ length: size }, () => 0);
  for (let row = size - 1; row >= 0; row -= 1) {
    let sum = augmented[row][size];
    for (let col = row + 1; col < size; col += 1) sum -= augmented[row][col] * solution[col];
    solution[row] = sum / (augmented[row][row] || 1e-9);
  }
  return solution;
}

function trainLandmarkModel(examples: LandmarkExample[], rng: () => number) {
  const { train, test } = splitExamples(examples, rng);
  const featureCount = train[0].features.length + 1;
  const outputCount = train[0].targets.length;
  const ridge = 2.5;
  const normal = Array.from({ length: featureCount }, () => Array.from({ length: featureCount }, () => 0));
  const design = train.map((item) => [1, ...item.features]);

  for (const x of design) {
    for (let i = 0; i < featureCount; i += 1) {
      for (let j = 0; j < featureCount; j += 1) normal[i][j] += x[i] * x[j];
    }
  }
  for (let i = 1; i < featureCount; i += 1) normal[i][i] += ridge;

  const outputs: number[][] = [];
  for (let output = 0; output < outputCount; output += 1) {
    const right = Array.from({ length: featureCount }, () => 0);
    design.forEach((x, index) => {
      for (let i = 0; i < featureCount; i += 1) right[i] += x[i] * train[index].targets[output];
    });
    outputs.push(solveLinearSystem(normal, right));
  }

  const model: LandmarkModel = {
    name: "Local ridge silhouette-to-keypoint regressor",
    width: MASK_WIDTH,
    height: MASK_HEIGHT,
    bands: MASK_BANDS,
    featureCount: featureCount - 1,
    ridge,
    outputs,
  };
  return { model, train, test };
}

export function inferLandmarkTargets(features: number[], model: LandmarkModel) {
  const x = [1, ...features];
  return model.outputs.map((coefficients) => clamp(coefficients.reduce((sum, weight, i) => sum + weight * (x[i] ?? 0), 0), 0.02, 0.98));
}

export function targetsToKeypoints(targets: number[]): Keypoints {
  const result: Keypoints = {};
  KEYPOINT_ORDER.forEach((key, index) => {
    result[key] = { x: clamp(targets[index * 2] ?? 0.5, 0.02, 0.98), y: clamp(targets[index * 2 + 1] ?? 0.5, 0.02, 0.98) };
  });
  return result;
}

function evaluateLandmarkModel(model: LandmarkModel, test: LandmarkExample[]) {
  const perKeypoint = Object.fromEntries(KEYPOINT_ORDER.map((key) => [key, 0])) as Record<KeypointKey, number>;
  let totalPixelError = 0;
  let totalNormalizedError = 0;
  let comparisons = 0;
  for (const item of test) {
    const predicted = inferLandmarkTargets(item.features, model);
    KEYPOINT_ORDER.forEach((key, index) => {
      const dx = predicted[index * 2] - item.targets[index * 2];
      const dy = predicted[index * 2 + 1] - item.targets[index * 2 + 1];
      const pixelError = Math.hypot(dx * MASK_WIDTH, dy * MASK_HEIGHT);
      perKeypoint[key] += pixelError;
      totalPixelError += pixelError;
      totalNormalizedError += Math.hypot(dx, dy);
      comparisons += 1;
    });
  }
  for (const key of KEYPOINT_ORDER) perKeypoint[key] = Math.round((perKeypoint[key] / Math.max(test.length, 1)) * 100) / 100;
  return {
    meanPixelError: Math.round((totalPixelError / Math.max(comparisons, 1)) * 100) / 100,
    meanNormalizedError: Math.round((totalNormalizedError / Math.max(comparisons, 1)) * 1000) / 1000,
    perKeypointPixelError: perKeypoint,
  };
}

export function trainAndTestModels(options?: { seed?: number; riskSamples?: number; landmarkSamples?: number }) {
  const seed = options?.seed ?? 20260320;
  const riskSamples = options?.riskSamples ?? 4000;
  const landmarkSamples = options?.landmarkSamples ?? 900;
  const riskRng = mulberry32(seed);
  const landmarkRng = mulberry32(seed + 977);
  const riskDataset = generateRiskExamples(riskSamples, riskRng);
  const landmarkDataset = generateLandmarkExamples(landmarkSamples, landmarkRng);
  const trainedRisk = trainRiskModel(riskDataset, mulberry32(seed + 31));
  const trainedLandmarks = trainLandmarkModel(landmarkDataset, mulberry32(seed + 67));
  const riskMetrics = evaluateClassifier(trainedRisk.model, trainedRisk.test);
  const landmarkMetrics = evaluateLandmarkModel(trainedLandmarks.model, trainedLandmarks.test);

  const weights: ModelWeights = {
    version: "stridecare-local-2.0",
    seed,
    risk: trainedRisk.model,
    landmarks: trainedLandmarks.model,
  };
  const report: ModelReport = {
    version: weights.version,
    seed,
    generatedAt: new Date().toISOString(),
    risk: {
      trainSize: trainedRisk.train.length,
      testSize: trainedRisk.test.length,
      positiveRate: Math.round((riskDataset.reduce((sum, item) => sum + item.label, 0) / riskDataset.length) * 1000) / 1000,
      accuracy: Math.round(riskMetrics.accuracy * 1000) / 1000,
      precision: Math.round(riskMetrics.precision * 1000) / 1000,
      recall: Math.round(riskMetrics.recall * 1000) / 1000,
      f1: Math.round(riskMetrics.f1 * 1000) / 1000,
      rocAuc: Math.round(riskMetrics.rocAuc * 1000) / 1000,
      confusion: riskMetrics.confusion,
      finalLoss: trainedRisk.finalLoss,
      lossCurve: trainedRisk.lossCurve,
      epochs: trainedRisk.model.epochs,
    },
    landmarks: {
      trainSize: trainedLandmarks.train.length,
      testSize: trainedLandmarks.test.length,
      ...landmarkMetrics,
      featureCount: trainedLandmarks.model.featureCount,
      ridge: trainedLandmarks.model.ridge,
    },
    notes: [
      "Models are trained and evaluated locally from deterministic synthetic data.",
      "No external AI API, cloud model, or pretrained third-party weights are used.",
      "Synthetic-test metrics are software benchmarks, not clinical validation on patient data.",
      "Landmark predictions are approximate seeds and should be reviewed or manually refined.",
    ],
  };
  return { weights, report };
}
