import {
  KEYPOINT_ORDER,
  type AssessmentPayload,
  type ClinicalProfile,
  type Keypoints,
  type MediaInfo,
} from "@/lib/types";

function validNumber(value: unknown, min: number, max: number) {
  return typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
}

export function parseAssessmentPayload(body: unknown): AssessmentPayload {
  if (!body || typeof body !== "object") throw new Error("Invalid assessment payload");
  if (JSON.stringify(body).length > 15_000_000) throw new Error("Captured frames are too large");
  const input = body as Record<string, unknown>;
  const p = input.patient as Record<string, unknown> | undefined;
  const m = input.media as Record<string, unknown> | undefined;
  const k = input.keypoints as Record<string, unknown> | undefined;

  if (!p || !m || !k) throw new Error("Patient, media and keypoints are required");
  if (typeof p.name !== "string" || p.name.trim().length < 2) throw new Error("Enter a patient name");
  if (!validNumber(p.age, 1, 120)) throw new Error("Enter a valid age");
  if (!validNumber(p.heightCm, 80, 250) || !validNumber(p.weightKg, 20, 300)) {
    throw new Error("Enter valid height and weight");
  }
  if (!validNumber(p.painLevel, 0, 10)) throw new Error("Pain level must be between 0 and 10");
  if (!["female", "male", "other"].includes(String(p.sex))) throw new Error("Invalid sex");
  if (!["low", "moderate", "high"].includes(String(p.activityLevel))) throw new Error("Invalid activity level");

  const patient: ClinicalProfile = {
    name: p.name.trim().slice(0, 120),
    age: Math.round(p.age as number),
    sex: p.sex as ClinicalProfile["sex"],
    heightCm: p.heightCm as number,
    weightKg: p.weightKg as number,
    painLevel: Math.round(p.painLevel as number),
    morningStiffness: Boolean(p.morningStiffness),
    priorInjury: Boolean(p.priorInjury),
    familyHistory: Boolean(p.familyHistory),
    activityLevel: p.activityLevel as ClinicalProfile["activityLevel"],
    notes: typeof p.notes === "string" ? p.notes.slice(0, 1000) : "",
  };

  if (!["image", "video", "sample"].includes(String(m.type))) throw new Error("Invalid media type");
  if (!Array.isArray(m.frames) || m.frames.length === 0 || m.frames.length > 6) {
    throw new Error("Between 1 and 6 captured frames are required");
  }
  if (!m.frames.every((frame) => typeof frame === "string" && frame.length < 3_000_000)) {
    throw new Error("A captured frame is too large or invalid");
  }
  if (!m.frames.every((frame) => frame.startsWith("data:image/") || frame.startsWith("/images/"))) {
    throw new Error("Frames must be image data URLs or bundled sample images");
  }
  if (!validNumber(m.aspectRatio, 0.4, 3)) throw new Error("Invalid frame aspect ratio");
  if (!validNumber(m.selectedFrame, 0, m.frames.length - 1)) throw new Error("Invalid selected frame");

  const media: MediaInfo = {
    type: m.type as MediaInfo["type"],
    fileName: typeof m.fileName === "string" ? m.fileName.slice(0, 200) : "uploaded-media",
    durationSec: validNumber(m.durationSec, 0, 3600) ? (m.durationSec as number) : undefined,
    aspectRatio: m.aspectRatio as number,
    frames: m.frames as string[],
    selectedFrame: Math.round(m.selectedFrame as number),
  };

  const keypoints: Keypoints = {};
  for (const key of KEYPOINT_ORDER) {
    const point = k[key] as Record<string, unknown> | undefined;
    if (!point || !validNumber(point.x, 0, 1) || !validNumber(point.y, 0, 1)) {
      throw new Error("All six body keypoints must be marked before saving");
    }
    keypoints[key] = { x: point.x as number, y: point.y as number };
  }

  return { patient, media, keypoints };
}
