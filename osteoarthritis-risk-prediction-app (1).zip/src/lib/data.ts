import { db } from "@/db";
import { assessments, patients } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { calculateRisk, computeMetrics } from "@/lib/analysis";
import {
  DEMO_FRAME,
  DEMO_KEYPOINTS,
  type AssessmentPayload,
  type AssessmentRecord,
  type ClinicalProfile,
  type DoctorStatus,
  type Keypoints,
} from "@/lib/types";

type AssessmentRow = typeof assessments.$inferSelect;
type PatientRow = typeof patients.$inferSelect;
type JoinedRow = { assessment: AssessmentRow; patient: PatientRow };

function toRecord(row: JoinedRow): AssessmentRecord {
  const { assessment: a, patient: p } = row;
  const patient: ClinicalProfile = {
    name: p.name,
    age: p.age,
    sex: p.sex,
    heightCm: p.heightCm,
    weightKg: p.weightKg,
    painLevel: p.painLevel,
    morningStiffness: p.morningStiffness,
    priorInjury: p.priorInjury,
    familyHistory: p.familyHistory,
    activityLevel: p.activityLevel,
    notes: p.notes,
  };

  return {
    id: a.id,
    patient,
    media: {
      type: a.mediaType,
      fileName: a.fileName,
      durationSec: a.durationSec ?? undefined,
      aspectRatio: a.aspectRatio,
      frames: a.frames,
      selectedFrame: a.selectedFrame,
    },
    keypoints: a.keypoints,
    metrics: a.metrics,
    risk: {
      score: a.score,
      band: a.band,
      bmi: a.bmi,
      probability: a.score / 100,
      drivers: a.drivers,
      recommendations: a.recommendations,
      metrics: a.metrics,
    },
    score: a.score,
    band: a.band,
    drivers: a.drivers,
    recommendations: a.recommendations,
    doctorStatus: a.doctorStatus,
    doctorNotes: a.doctorNotes,
    createdAt: a.createdAt.toISOString(),
    reviewedAt: a.reviewedAt ? a.reviewedAt.toISOString() : null,
  };
}

const demoCases: Array<{
  profile: ClinicalProfile;
  status: DoctorStatus;
  notes: string;
  daysAgo: number;
  keypoints: Keypoints;
}> = [
  {
    profile: {
      name: "Anita Sharma",
      age: 68,
      sex: "female",
      heightCm: 158,
      weightKg: 81,
      painLevel: 7,
      morningStiffness: true,
      priorInjury: true,
      familyHistory: true,
      activityLevel: "low",
      notes: "Medial knee discomfort while climbing stairs; stiffness on waking.",
    },
    status: "Follow-up",
    notes: "Recommend weight-bearing imaging review and a supervised quadriceps program. Reassess in 4 weeks.",
    daysAgo: 1,
    keypoints: DEMO_KEYPOINTS,
  },
  {
    profile: {
      name: "Rahul Mehta",
      age: 54,
      sex: "male",
      heightCm: 174,
      weightKg: 84,
      painLevel: 4,
      morningStiffness: true,
      priorInjury: false,
      familyHistory: false,
      activityLevel: "moderate",
      notes: "Intermittent right knee ache after longer walks.",
    },
    status: "Pending review",
    notes: "",
    daysAgo: 3,
    keypoints: {
      ...DEMO_KEYPOINTS,
      rightKnee: { x: 0.53, y: 0.64 },
      rightAnkle: { x: 0.61, y: 0.85 },
    },
  },
  {
    profile: {
      name: "Elena Rodriguez",
      age: 36,
      sex: "female",
      heightCm: 168,
      weightKg: 61,
      painLevel: 1,
      morningStiffness: false,
      priorInjury: false,
      familyHistory: false,
      activityLevel: "high",
      notes: "Baseline gait screening for a recreational runner.",
    },
    status: "Reviewed",
    notes: "No concerning symptoms. Continue preventive strength work and annual screening.",
    daysAgo: 6,
    keypoints: DEMO_KEYPOINTS,
  },
  {
    profile: {
      name: "David Okafor",
      age: 47,
      sex: "male",
      heightCm: 180,
      weightKg: 88,
      painLevel: 3,
      morningStiffness: false,
      priorInjury: true,
      familyHistory: false,
      activityLevel: "moderate",
      notes: "Old sports injury; wants a baseline before returning to regular running.",
    },
    status: "Reviewed",
    notes: "Discuss gradual return to activity, footwear and a 6-week reassessment.",
    daysAgo: 9,
    keypoints: {
      ...DEMO_KEYPOINTS,
      leftKnee: { x: 0.435, y: 0.66 },
      leftAnkle: { x: 0.405, y: 0.865 },
    },
  },
];

let seedPromise: Promise<void> | null = null;

async function seedDatabase() {
  const count = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(assessments);
  if ((count[0]?.value ?? 0) > 0) return;

  for (const item of demoCases) {
    const createdAt = new Date(Date.now() - item.daysAgo * 24 * 60 * 60 * 1000);
    const metrics = computeMetrics(item.keypoints, 1.5);
    const risk = calculateRisk(item.profile, metrics);
    const [patient] = await db
      .insert(patients)
      .values({ ...item.profile, createdAt })
      .returning();

    await db.insert(assessments).values({
      patientId: patient.id,
      mediaType: "sample",
      fileName: "sample-gait-frame.jpg",
      aspectRatio: 1.5,
      frames: [DEMO_FRAME],
      selectedFrame: 0,
      keypoints: item.keypoints,
      metrics,
      score: risk.score,
      band: risk.band,
      bmi: risk.bmi,
      drivers: risk.drivers,
      recommendations: risk.recommendations,
      doctorStatus: item.status,
      doctorNotes: item.notes,
      createdAt,
      reviewedAt: item.status === "Pending review" ? null : createdAt,
    });
  }
}

export function ensureSeedData() {
  if (!seedPromise) {
    seedPromise = seedDatabase().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export async function getAssessmentRecords(): Promise<AssessmentRecord[]> {
  await ensureSeedData();
  const rows = await db
    .select({ assessment: assessments, patient: patients })
    .from(assessments)
    .innerJoin(patients, eq(assessments.patientId, patients.id))
    .orderBy(desc(assessments.createdAt));
  return rows.map(toRecord);
}

export async function getAssessmentRecord(id: number): Promise<AssessmentRecord | null> {
  await ensureSeedData();
  const rows = await db
    .select({ assessment: assessments, patient: patients })
    .from(assessments)
    .innerJoin(patients, eq(assessments.patientId, patients.id))
    .where(eq(assessments.id, id))
    .limit(1);
  return rows[0] ? toRecord(rows[0]) : null;
}

export async function createAssessment(payload: AssessmentPayload): Promise<AssessmentRecord> {
  await ensureSeedData();
  return db.transaction(async (tx) => {
    const [patient] = await tx
      .insert(patients)
      .values(payload.patient)
      .returning();
    const metrics = computeMetrics(payload.keypoints, payload.media.aspectRatio);
    const risk = calculateRisk(payload.patient, metrics);
    const [assessment] = await tx
      .insert(assessments)
      .values({
        patientId: patient.id,
        mediaType: payload.media.type,
        fileName: payload.media.fileName,
        durationSec: payload.media.durationSec ?? null,
        aspectRatio: payload.media.aspectRatio,
        frames: payload.media.frames,
        selectedFrame: payload.media.selectedFrame,
        keypoints: payload.keypoints,
        metrics,
        score: risk.score,
        band: risk.band,
        bmi: risk.bmi,
        drivers: risk.drivers,
        recommendations: risk.recommendations,
      })
      .returning();
    return toRecord({ assessment, patient });
  });
}

export async function updateAssessmentReview(
  id: number,
  status: DoctorStatus,
  notes: string,
): Promise<AssessmentRecord | null> {
  await db
    .update(assessments)
    .set({
      doctorStatus: status,
      doctorNotes: notes,
      reviewedAt: new Date(),
    })
    .where(eq(assessments.id, id));
  return getAssessmentRecord(id);
}
