import {
  MASK_BANDS,
  MASK_HEIGHT,
  MASK_WIDTH,
  extractMaskFeatures,
  inferLandmarkTargets,
  targetsToKeypoints,
  type LandmarkModel,
} from "./ml-core";
import { LANDMARK_MODEL } from "./models";
import { KEYPOINT_ORDER, type Keypoints, type Point } from "./types";

export type LandmarkInference = {
  keypoints: Keypoints;
  confidence: number;
  coverage: number;
  bbox: number[];
  mask: number[];
  modelName: string;
};

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

function median(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] ?? 0;
}

function buildSilhouetteMask(image: HTMLImageElement | HTMLCanvasElement) {
  const canvas = document.createElement("canvas");
  canvas.width = MASK_WIDTH;
  canvas.height = MASK_HEIGHT;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Canvas is not available for local landmark inference");
  context.drawImage(image, 0, 0, MASK_WIDTH, MASK_HEIGHT);
  const pixels = context.getImageData(0, 0, MASK_WIDTH, MASK_HEIGHT).data;
  const mask = new Uint8Array(MASK_WIDTH * MASK_HEIGHT);
  const borderX = [0, 1, 2, MASK_WIDTH - 3, MASK_WIDTH - 2, MASK_WIDTH - 1];

  for (let y = 0; y < MASK_HEIGHT; y += 1) {
    const reds: number[] = [];
    const greens: number[] = [];
    const blues: number[] = [];
    for (const x of borderX) {
      const offset = (y * MASK_WIDTH + x) * 4;
      reds.push(pixels[offset]);
      greens.push(pixels[offset + 1]);
      blues.push(pixels[offset + 2]);
    }
    const background = [median(reds), median(greens), median(blues)];
    for (let x = 0; x < MASK_WIDTH; x += 1) {
      const offset = (y * MASK_WIDTH + x) * 4;
      const distance = Math.hypot(
        pixels[offset] - background[0],
        pixels[offset + 1] - background[1],
        pixels[offset + 2] - background[2],
      ) / Math.sqrt(3);
      if (distance > 34) mask[y * MASK_WIDTH + x] = 1;
    }
  }
  return mask;
}

function anatomicalPrior(bbox: number[]): Keypoints {
  const [minX, minY, width, height] = bbox;
  const center = minX + width / 2;
  const hipY = minY + height * 0.43;
  const kneeY = minY + height * 0.7;
  const ankleY = minY + height * 0.94;
  return {
    leftHip: { x: center - width * 0.05, y: hipY },
    leftKnee: { x: center - width * 0.1, y: kneeY },
    leftAnkle: { x: center - width * 0.16, y: ankleY },
    rightHip: { x: center + width * 0.05, y: hipY },
    rightKnee: { x: center + width * 0.1, y: kneeY },
    rightAnkle: { x: center + width * 0.16, y: ankleY },
  };
}

export function inferKeypointsFromImage(
  image: HTMLImageElement | HTMLCanvasElement,
  model: LandmarkModel = LANDMARK_MODEL,
): LandmarkInference {
  const mask = buildSilhouetteMask(image);
  const { features, foregroundCoverage, bbox } = extractMaskFeatures(mask, model.width, model.height, model.bands);
  const targets = inferLandmarkTargets(features, model);
  const learned = targetsToKeypoints(targets);

  const coverageScore =
    foregroundCoverage < 0.03
      ? foregroundCoverage / 0.03
      : foregroundCoverage > 0.55
        ? clamp((1 - foregroundCoverage) / 0.45, 0, 1)
        : 1;
  const heightScore = clamp((bbox[3] ?? 0) / 0.6, 0, 1);
  const confidence = clamp(coverageScore * heightScore, 0.15, 1);
  const blend = clamp(confidence, 0.35, 0.9);
  const prior = anatomicalPrior(bbox);
  const keypoints: Keypoints = {};

  for (const key of KEYPOINT_ORDER) {
    const a: Point = learned[key] ?? { x: 0.5, y: 0.5 };
    const b: Point = prior[key] ?? { x: 0.5, y: 0.5 };
    keypoints[key] = {
      x: clamp(a.x * blend + b.x * (1 - blend), 0.02, 0.98),
      y: clamp(a.y * blend + b.y * (1 - blend), 0.02, 0.98),
    };
  }

  return {
    keypoints,
    confidence,
    coverage: Math.round(foregroundCoverage * 1000) / 1000,
    bbox,
    mask: Array.from(mask),
    modelName: model.name,
  };
}
