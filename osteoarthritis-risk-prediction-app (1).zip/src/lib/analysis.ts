import { predictRiskProbability, riskScoreFromProbability } from "./ml-core";
import { MODEL_WEIGHTS, RISK_MODEL } from "./models";
import {
  KEYPOINT_ORDER,
  type ClinicalProfile,
  type KeypointKey,
  type Keypoints,
  type Metrics,
  type Point,
  type RiskBand,
  type RiskResult,
} from "./types";

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

const scaled = (point: Point, aspectRatio: number): Point => ({
  x: point.x * aspectRatio,
  y: point.y,
});

function internalAngle(a: Point, b: Point, c: Point, aspectRatio: number) {
  const p1 = scaled(a, aspectRatio);
  const p2 = scaled(b, aspectRatio);
  const p3 = scaled(c, aspectRatio);
  const v1 = { x: p1.x - p2.x, y: p1.y - p2.y };
  const v2 = { x: p3.x - p2.x, y: p3.y - p2.y };
  const magnitude = Math.hypot(v1.x, v1.y) * Math.hypot(v2.x, v2.y);
  if (!magnitude) return 180;
  const cosine = clamp((v1.x * v2.x + v1.y * v2.y) / magnitude, -1, 1);
  return (Math.acos(cosine) * 180) / Math.PI;
}

function distanceFromLine(point: Point, start: Point, end: Point, aspectRatio: number) {
  const p = scaled(point, aspectRatio);
  const a = scaled(start, aspectRatio);
  const b = scaled(end, aspectRatio);
  const length = Math.hypot(b.x - a.x, b.y - a.y);
  if (!length) return 0;
  return Math.abs((b.x - a.x) * (a.y - p.y) - (a.x - p.x) * (b.y - a.y)) / length;
}

function legLength(hip: Point, knee: Point, ankle: Point, aspectRatio: number) {
  const h = scaled(hip, aspectRatio);
  const k = scaled(knee, aspectRatio);
  const a = scaled(ankle, aspectRatio);
  return Math.hypot(k.x - h.x, k.y - h.y) + Math.hypot(a.x - k.x, a.y - k.y);
}

export function computeMetrics(keypoints: Keypoints, aspectRatio = 1.5): Metrics {
  const ratio = clamp(aspectRatio || 1.5, 0.4, 3);
  const keypointCount = KEYPOINT_ORDER.filter((key) => keypoints[key]).length;
  const empty: Metrics = {
    leftFlexion: 0,
    rightFlexion: 0,
    avgFlexion: 0,
    asymmetry: 0,
    alignmentDeviation: 0,
    strideSpread: 0,
    gaitConfidence: Math.round((keypointCount / 6) * 100),
    keypointCount,
    aspectRatio: ratio,
  };

  const required = [
    keypoints.leftHip,
    keypoints.leftKnee,
    keypoints.leftAnkle,
    keypoints.rightHip,
    keypoints.rightKnee,
    keypoints.rightAnkle,
  ];
  if (required.some((point) => !point)) return empty;

  const lh = keypoints.leftHip!;
  const lk = keypoints.leftKnee!;
  const la = keypoints.leftAnkle!;
  const rh = keypoints.rightHip!;
  const rk = keypoints.rightKnee!;
  const ra = keypoints.rightAnkle!;

  const leftFlexion = clamp(180 - internalAngle(lh, lk, la, ratio), 0, 120);
  const rightFlexion = clamp(180 - internalAngle(rh, rk, ra, ratio), 0, 120);
  const leftLength = legLength(lh, lk, la, ratio);
  const rightLength = legLength(rh, rk, ra, ratio);
  const leftDeviation = distanceFromLine(lk, lh, la, ratio) / Math.max(leftLength, 0.01);
  const rightDeviation = distanceFromLine(rk, rh, ra, ratio) / Math.max(rightLength, 0.01);
  const ankleDistance = Math.hypot(
    (ra.x - la.x) * ratio,
    ra.y - la.y,
  );
  const meanLegLength = Math.max((leftLength + rightLength) / 2, 0.01);

  return {
    leftFlexion: Math.round(leftFlexion * 10) / 10,
    rightFlexion: Math.round(rightFlexion * 10) / 10,
    avgFlexion: Math.round(((leftFlexion + rightFlexion) / 2) * 10) / 10,
    asymmetry: Math.round(Math.abs(leftFlexion - rightFlexion) * 10) / 10,
    alignmentDeviation: Math.round(((leftDeviation + rightDeviation) / 2) * 1000) / 1000,
    strideSpread: Math.round((ankleDistance / meanLegLength) * 1000) / 1000,
    gaitConfidence: 100,
    keypointCount,
    aspectRatio: ratio,
  };
}

export function getBand(score: number): RiskBand {
  if (score >= 60) return "High";
  if (score >= 30) return "Moderate";
  return "Low";
}

export function calculateBMI(profile: ClinicalProfile) {
  const meters = Math.max(profile.heightCm / 100, 0.5);
  return Math.round((profile.weightKg / (meters * meters)) * 10) / 10;
}

export function calculateRisk(profile: ClinicalProfile, metrics: Metrics): RiskResult {
  const bmi = calculateBMI(profile);
  const drivers: string[] = [];
  const recommendations: string[] = [];
  const explain = (reason: string) => drivers.push(reason);

  // The numerical score comes from locally learned weights. The rules below are
  // retained only as transparent, human-readable explanations and cautions.
  const probability = predictRiskProbability(profile, metrics, RISK_MODEL);
  const score = riskScoreFromProbability(probability, RISK_MODEL);
  const band = getBand(score);

  explain(`${MODEL_WEIGHTS.version}: logistic model combined ${RISK_MODEL.featureNames.length} standardised intake and gait features`);
  explain(`Calibrated model output: ${(probability * 100).toFixed(1)}% elevated-marker probability`);

  if (profile.age >= 65) explain(`Age ${profile.age} is a strong non-modifiable risk factor`);
  else if (profile.age >= 50) explain(`Age ${profile.age} increases susceptibility`);
  else if (profile.age >= 40) explain("Age over 40 slightly increases susceptibility");

  if (bmi >= 30) explain(`BMI ${bmi} increases knee joint loading`);
  else if (bmi >= 25) explain(`BMI ${bmi} adds avoidable knee load`);

  if (profile.painLevel >= 7) explain(`Reported knee pain is high (${profile.painLevel}/10)`);
  else if (profile.painLevel >= 4) explain(`Reported knee pain is moderate (${profile.painLevel}/10)`);
  else if (profile.painLevel >= 2) explain(`Mild knee pain reported (${profile.painLevel}/10)`);

  if (profile.morningStiffness) explain("Morning stiffness lasting over 20 minutes");
  if (profile.priorInjury) explain("Previous knee injury or surgery");
  if (profile.familyHistory) explain("Family history of osteoarthritis");
  if (profile.activityLevel === "low") explain("Low activity level may reduce joint support");

  if (metrics.gaitConfidence === 100) {
    if (metrics.avgFlexion < 35) explain(`Low observed knee flexion in sampled frame (${metrics.avgFlexion.toFixed(0)}°)`);
    else if (metrics.avgFlexion < 50) explain(`Reduced observed knee flexion in sampled frame (${metrics.avgFlexion.toFixed(0)}°)`);

    if (metrics.asymmetry >= 12) explain(`Left-right flexion asymmetry (${metrics.asymmetry.toFixed(0)}°)`);
    else if (metrics.asymmetry >= 7) explain(`Mild left-right asymmetry (${metrics.asymmetry.toFixed(0)}°)`);

    if (metrics.alignmentDeviation >= 0.12) explain("Visible knee alignment deviation");
    else if (metrics.alignmentDeviation >= 0.07) explain("Mild frontal-plane alignment deviation");
  } else {
    explain("Incomplete keypoint annotation — gait markers defaulted to zero");
  }

  recommendations.push(
    "Use this screening result with a physical examination, symptom history and imaging when indicated.",
    "Reassess the same walking view every 4–6 weeks to compare flexion and symmetry trends.",
  );
  if (bmi >= 25) recommendations.push("A gradual weight-management plan can meaningfully reduce load across the knee.");
  if (profile.painLevel >= 4 || profile.morningStiffness) {
    recommendations.push("Avoid high-impact loading during painful flares; prefer cycling, aquatic exercise or short walks.");
  }
  if (profile.activityLevel === "low" || metrics.avgFlexion < 50) {
    recommendations.push("Add low-impact range-of-motion and quadriceps/hip strengthening, guided by a physiotherapist.");
  }
  if (metrics.asymmetry >= 7) {
    recommendations.push("Check footwear, stance and unilateral loading; consider a supervised gait retraining session.");
  }
  if (band === "High") {
    recommendations.push("Arrange a clinician review and discuss early imaging or orthopaedic referral if symptoms persist.");
  } else if (band === "Moderate") {
    recommendations.push("Schedule a follow-up review and track pain, stiffness and walking distance in a symptom diary.");
  } else {
    recommendations.push("Maintain regular low-impact activity, strength work and a healthy body weight as prevention.");
  }

  return { score, band, bmi, probability, drivers, recommendations, metrics };
}

export function keypointIsComplete(keypoints: Keypoints, key?: KeypointKey) {
  if (key) return Boolean(keypoints[key]);
  return KEYPOINT_ORDER.every((item) => Boolean(keypoints[item]));
}
