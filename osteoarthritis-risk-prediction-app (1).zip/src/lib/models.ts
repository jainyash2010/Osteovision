import rawReport from "./models/report.json";
import rawWeights from "./models/weights.json";
import type { LandmarkModel, ModelReport, ModelWeights, RiskModel } from "./ml-core";

export const MODEL_WEIGHTS = rawWeights as ModelWeights;
export const MODEL_REPORT = rawReport as ModelReport;
export const RISK_MODEL: RiskModel = MODEL_WEIGHTS.risk;
export const LANDMARK_MODEL: LandmarkModel = MODEL_WEIGHTS.landmarks;
