"use client";

import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Bone,
  Camera,
  Check,
  ChevronRight,
  CircleAlert,
  FileImage,
  FileVideo2,
  Info,
  Loader2,
  RotateCcw,
  Save,
  ScanFace,
  Sparkles,
  UploadCloud,
  WandSparkles,
} from "lucide-react";
import { saveAssessment } from "@/app/actions";
import Link from "next/link";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
} from "react";
import PoseCanvas from "@/components/PoseCanvas";
import { RiskBadge, ScoreGauge } from "@/components/ui";
import { calculateBMI, calculateRisk, computeMetrics } from "@/lib/analysis";
import { inferKeypointsFromImage } from "@/lib/vision";
import {
  DEFAULT_PROFILE,
  DEMO_FRAME,
  DEMO_KEYPOINTS,
  KEYPOINT_LABELS,
  KEYPOINT_ORDER,
  type ClinicalProfile,
  type KeypointKey,
  type Keypoints,
  type MediaInfo,
  type Point,
} from "@/lib/types";

const STEPS = [
  { title: "Patient intake", subtitle: "Symptoms & profile" },
  { title: "Upload media", subtitle: "Photo or video" },
  { title: "Mark keypoints", subtitle: "Hips, knees, ankles" },
  { title: "Risk result", subtitle: "Save & share" },
];

const MAX_FILE_BYTES = 40 * 1024 * 1024;

function compressFrame(source: CanvasImageSource, width: number, height: number) {
  const canvas = document.createElement("canvas");
  const scale = Math.min(1, 1100 / Math.max(width, 1));
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas capture is not available in this browser");
  context.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.82);
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not read this image"));
    image.src = src;
  });
}

function seekVideo(video: HTMLVideoElement, time: number) {
  return new Promise<void>((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      window.clearTimeout(timer);
      video.removeEventListener("seeked", finish);
      resolve();
    };
    const timer = window.setTimeout(finish, 3500);
    video.addEventListener("seeked", finish);
    video.currentTime = time;
  });
}

async function extractVideoFrames(url: string, reportedDuration: number) {
  const video = document.createElement("video");
  video.preload = "auto";
  video.muted = true;
  video.playsInline = true;
  video.src = url;
  await new Promise<void>((resolve, reject) => {
    if (video.readyState >= 1) {
      resolve();
      return;
    }
    video.onloadedmetadata = () => resolve();
    video.onerror = () => reject(new Error("Could not decode this video"));
  });
  const duration =
    Number.isFinite(video.duration) && video.duration > 0
      ? video.duration
      : Number.isFinite(reportedDuration) && reportedDuration > 0
        ? reportedDuration
        : 4;
  const times = [0.12, 0.36, 0.6, 0.84].map((fraction) =>
    Math.min(Math.max(fraction * duration, 0.02), Math.max(duration - 0.05, 0.02)),
  );
  const frames: string[] = [];
  for (const time of times) {
    await seekVideo(video, time);
    await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    frames.push(compressFrame(video, video.videoWidth, video.videoHeight));
  }
  const unique = frames.filter((frame, index) => frames.indexOf(frame) === index);
  return { frames: unique.length ? unique : frames.slice(0, 1), duration };
}

function ToggleCard({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`flex w-full items-start gap-3 rounded-xl border p-3.5 text-left transition ${
        checked ? "border-teal-300 bg-teal-50/70" : "border-slate-200 bg-white hover:border-slate-300"
      }`}
    >
      <span
        className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border ${
          checked ? "border-teal-600 bg-teal-600 text-white" : "border-slate-300 bg-white"
        }`}
      >
        {checked && <Check size={13} strokeWidth={3} />}
      </span>
      <span>
        <span className="block text-sm font-bold text-[#102a43]">{label}</span>
        <span className="mt-0.5 block text-xs leading-relaxed text-slate-500">{description}</span>
      </span>
    </button>
  );
}

export default function AssessmentStudio() {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<ClinicalProfile>(DEFAULT_PROFILE);
  const [media, setMedia] = useState<MediaInfo | null>(null);
  const [keypoints, setKeypoints] = useState<Keypoints>({});
  const [activeKey, setActiveKey] = useState<KeypointKey | null>("leftHip");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<number | null>(null);
  const [notice, setNotice] = useState<{ type: "error" | "success"; text: string } | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  const metrics = useMemo(
    () => computeMetrics(keypoints, media?.aspectRatio ?? 1.5),
    [keypoints, media?.aspectRatio],
  );
  const risk = useMemo(() => calculateRisk(profile, metrics), [profile, metrics]);
  const bmi = calculateBMI(profile);
  const keypointCount = KEYPOINT_ORDER.filter((key) => keypoints[key]).length;
  const complete = keypointCount === 6;
  const selectedFrame = media?.frames[media.selectedFrame] ?? "";

  function updateProfile<K extends keyof ClinicalProfile>(key: K, value: ClinicalProfile[K]) {
    setProfile((previous) => ({ ...previous, [key]: value }));
    setSavedId(null);
  }

  function resetAnnotation() {
    setKeypoints({});
    setActiveKey("leftHip");
    setSavedId(null);
  }

  async function handleImage(file: File, objectUrl: string) {
    const image = await loadImage(objectUrl);
    const frame = compressFrame(image, image.naturalWidth, image.naturalHeight);
    setMedia({
      type: "image",
      fileName: file.name,
      aspectRatio: image.naturalWidth / image.naturalHeight,
      frames: [frame],
      selectedFrame: 0,
    });
    setVideoUrl(null);
    resetAnnotation();
    setNotice({ type: "success", text: "Photo captured. You can now mark six body keypoints." });
  }

  async function handleVideo(file: File, objectUrl: string) {
    const { frames, duration } = await extractVideoFrames(objectUrl, 0);
    const probe = await loadImage(frames[0]);
    setMedia({
      type: "video",
      fileName: file.name,
      durationSec: duration,
      aspectRatio: probe.naturalWidth / probe.naturalHeight,
      frames,
      selectedFrame: 0,
    });
    setVideoUrl(objectUrl);
    resetAnnotation();
    setNotice({ type: "success", text: `${frames.length} gait frames extracted from the video.` });
  }

  const handleFile = useCallback(async (file?: File | null) => {
    if (!file) return;
    setNotice(null);
    if (file.size > MAX_FILE_BYTES) {
      setNotice({ type: "error", text: "Please choose a photo or video under 40 MB." });
      return;
    }
    const isImage = file.type.startsWith("image/");
    const isVideo = file.type.startsWith("video/");
    if (!isImage && !isVideo) {
      setNotice({ type: "error", text: "Choose a JPG, PNG, WebP, MP4 or WebM file." });
      return;
    }
    const objectUrl = URL.createObjectURL(file);
    let keepObjectUrl = false;
    setProcessing(true);
    try {
      if (isImage) await handleImage(file, objectUrl);
      else {
        await handleVideo(file, objectUrl);
        keepObjectUrl = true;
      }
    } catch (error) {
      setNotice({
        type: "error",
        text: error instanceof Error ? error.message : "Unable to process this file. Try a different frame.",
      });
    } finally {
      if (!keepObjectUrl) URL.revokeObjectURL(objectUrl);
      setProcessing(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onFileInput(event: ChangeEvent<HTMLInputElement>) {
    void handleFile(event.target.files?.[0]);
    event.target.value = "";
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    void handleFile(event.dataTransfer.files?.[0]);
  }

  function loadSample() {
    setMedia({
      type: "sample",
      fileName: "sample-gait-frame.jpg",
      aspectRatio: 1.5,
      frames: [DEMO_FRAME],
      selectedFrame: 0,
    });
    setKeypoints(DEMO_KEYPOINTS);
    setActiveKey(null);
    setVideoUrl(null);
    setSavedId(null);
    setNotice({ type: "success", text: "Demo gait frame and example landmarks are ready." });
  }

  function loadDemoLandmarks() {
    setKeypoints(DEMO_KEYPOINTS);
    setActiveKey(null);
    setSavedId(null);
  }

  function selectFrame(index: number) {
    if (!media) return;
    setMedia({ ...media, selectedFrame: index });
    resetAnnotation();
    setNotice(null);
  }

  function captureCurrentVideoFrame() {
    const video = videoRef.current;
    if (!video || !media || video.readyState < 2) {
      setNotice({ type: "error", text: "Play or seek the video before capturing a frame." });
      return;
    }
    if (media.frames.length >= 6) {
      setNotice({ type: "error", text: "The maximum is six captured frames. Select one of the existing frames." });
      return;
    }
    const frame = compressFrame(video, video.videoWidth, video.videoHeight);
    const frames = [...media.frames, frame];
    setMedia({ ...media, frames, selectedFrame: frames.length - 1 });
    resetAnnotation();
    setNotice({ type: "success", text: "Current video frame captured and selected." });
  }

  function handleKeypointChange(key: KeypointKey, point: Point) {
    setKeypoints((previous) => ({ ...previous, [key]: point }));
    setSavedId(null);
  }

  function advanceKeypoint(current: KeypointKey) {
    const index = KEYPOINT_ORDER.indexOf(current);
    for (let offset = 1; offset <= KEYPOINT_ORDER.length; offset += 1) {
      const candidate = KEYPOINT_ORDER[(index + offset) % KEYPOINT_ORDER.length];
      if (!keypoints[candidate] && candidate !== current) {
        setActiveKey(candidate);
        return;
      }
    }
    setActiveKey(null);
  }

  async function autoDetect() {
    if (!selectedFrame) return;
    setDetecting(true);
    setNotice(null);
    try {
      const image = await loadImage(selectedFrame);
      const inference = inferKeypointsFromImage(image);
      setKeypoints(inference.keypoints);
      setActiveKey(null);
      setSavedId(null);
      setNotice({
        type: "success",
        text: `Local ridge-regression model placed six landmarks (${Math.round(inference.confidence * 100)}% segmentation confidence). Drag any point to refine.`,
      });
    } catch (error) {
      setNotice({
        type: "error",
        text: error instanceof Error ? error.message : "Local landmark inference failed. Please mark the points manually.",
      });
    } finally {
      setDetecting(false);
    }
  }

  async function saveReport() {
    if (!media || !complete) return;
    setSaving(true);
    setNotice(null);
    try {
      const record = await saveAssessment({ patient: profile, media, keypoints });
      setSavedId(record.id);
      setNotice({ type: "success", text: "Assessment saved through a server action. Doctor and patient views are now available." });
    } catch (error) {
      setNotice({
        type: "error",
        text: error instanceof Error ? error.message : "Unable to save this assessment",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="hero-glow bg-grid relative overflow-hidden rounded-3xl px-6 py-7 text-white shadow-xl shadow-slate-900/10 sm:px-8">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-6">
          <div className="max-w-2xl">
            <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20">
              <Sparkles size={13} /> Locally trained models · no external AI API
            </span>
            <h1 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">Turn a walking frame into an early knee-risk signal.</h1>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-teal-50/80">
              Capture a side-view photo or video, mark six body keypoints, and review knee flexion, asymmetry, alignment and an osteoarthritis screening score.
            </p>
          </div>
          <div className="hidden w-56 rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur-md md:block">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-100">
              <Activity size={15} /> Current derivation
            </div>
            <div className="mt-3 flex items-end justify-between">
              <span className="text-4xl font-extrabold">{risk.score}</span>
              <span className="text-xs font-semibold text-teal-100">/ 100</span>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/20">
              <div className="h-full rounded-full bg-teal-300 transition-all" style={{ width: `${risk.score}%` }} />
            </div>
            <p className="mt-3 text-xs text-teal-50/75">Updates live as clinical inputs and landmarks change.</p>
          </div>
        </div>
      </section>

      <section className="card p-4 sm:p-5">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {STEPS.map((item, index) => {
            const number = index + 1;
            const active = step === number;
            const done = step > number;
            return (
              <button
                key={item.title}
                type="button"
                disabled={number > step}
                onClick={() => setStep(number)}
                className={`flex items-center gap-3 rounded-xl border px-3 py-3 text-left transition ${
                  active
                    ? "border-teal-300 bg-teal-50"
                    : done
                      ? "border-emerald-200 bg-emerald-50/50"
                      : "border-slate-200 bg-white opacity-60"
                }`}
              >
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-extrabold ${
                    active
                      ? "bg-teal-600 text-white"
                      : done
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {done ? <Check size={15} strokeWidth={3} /> : number}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-bold text-[#102a43]">{item.title}</span>
                  <span className="block truncate text-xs text-slate-500">{item.subtitle}</span>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_330px]">
        <div className="space-y-6">
          {notice && (
            <div
              className={`flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm font-medium ${
                notice.type === "error"
                  ? "border-rose-200 bg-rose-50 text-rose-700"
                  : "border-emerald-200 bg-emerald-50 text-emerald-700"
              }`}
            >
              {notice.type === "error" ? <CircleAlert size={18} className="mt-0.5 shrink-0" /> : <Check size={18} className="mt-0.5 shrink-0" />}
              <span className="flex-1">{notice.text}</span>
              <button onClick={() => setNotice(null)} aria-label="Dismiss message" className="font-bold">×</button>
            </div>
          )}

          {step === 1 && (
            <section className="card p-6 sm:p-7">
              <div className="mb-6">
                <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Step 1 · Patient intake</p>
                <h2 className="mt-1 text-2xl font-extrabold tracking-tight">Symptoms and baseline profile</h2>
                <p className="mt-1 text-sm text-slate-500">These factors are combined with gait markers to produce the screening estimate.</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="sm:col-span-2 lg:col-span-1">
                  <label className="label" htmlFor="patient-name">Patient name *</label>
                  <input id="patient-name" className="input" value={profile.name} onChange={(e) => updateProfile("name", e.target.value)} placeholder="e.g. Maya Patel" />
                </div>
                <div>
                  <label className="label" htmlFor="patient-age">Age</label>
                  <input id="patient-age" type="number" min={1} max={120} className="input" value={profile.age} onChange={(e) => updateProfile("age", Number(e.target.value))} />
                </div>
                <div>
                  <label className="label" htmlFor="patient-sex">Sex</label>
                  <select id="patient-sex" className="input" value={profile.sex} onChange={(e) => updateProfile("sex", e.target.value as ClinicalProfile["sex"])}>
                    <option value="female">Female</option><option value="male">Male</option><option value="other">Other / prefer not to say</option>
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="height">Height (cm)</label>
                  <input id="height" type="number" min={80} max={250} className="input" value={profile.heightCm} onChange={(e) => updateProfile("heightCm", Number(e.target.value))} />
                </div>
                <div>
                  <label className="label" htmlFor="weight">Weight (kg)</label>
                  <input id="weight" type="number" min={20} max={300} className="input" value={profile.weightKg} onChange={(e) => updateProfile("weightKg", Number(e.target.value))} />
                </div>
                <div>
                  <label className="label">Calculated BMI</label>
                  <div className="input flex items-center justify-between bg-slate-50 font-bold text-teal-700">
                    <span>{bmi.toFixed(1)}</span>
                    <span className="text-xs font-semibold text-slate-400">kg/m²</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="!mb-0 text-sm font-bold text-[#102a43]" htmlFor="pain">Current knee pain</label>
                  <span className="chip bg-white text-teal-700 ring-1 ring-teal-200">{profile.painLevel} / 10</span>
                </div>
                <input id="pain" type="range" min={0} max={10} step={1} value={profile.painLevel} onChange={(e) => updateProfile("painLevel", Number(e.target.value))} className="mt-4 w-full" />
                <div className="mt-1 flex justify-between text-[0.68rem] font-semibold text-slate-400"><span>No pain</span><span>Moderate</span><span>Severe</span></div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <ToggleCard label="Morning stiffness" description="Lasting more than 20 minutes" checked={profile.morningStiffness} onChange={(v) => updateProfile("morningStiffness", v)} />
                <ToggleCard label="Previous knee injury" description="Including surgery or sports trauma" checked={profile.priorInjury} onChange={(v) => updateProfile("priorInjury", v)} />
                <ToggleCard label="Family history" description="OA in a first-degree relative" checked={profile.familyHistory} onChange={(v) => updateProfile("familyHistory", v)} />
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="activity">Activity level</label>
                  <select id="activity" className="input" value={profile.activityLevel} onChange={(e) => updateProfile("activityLevel", e.target.value as ClinicalProfile["activityLevel"])}>
                    <option value="low">Low · mostly sedentary</option><option value="moderate">Moderate · regular walking</option><option value="high">High · frequent exercise</option>
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="notes">Clinical notes</label>
                  <input id="notes" className="input" value={profile.notes} onChange={(e) => updateProfile("notes", e.target.value)} placeholder="Symptoms, duration, observations" />
                </div>
              </div>

              <div className="mt-7 flex justify-end">
                <button className="btn-primary" disabled={profile.name.trim().length < 2} onClick={() => setStep(2)}>
                  Continue to media <ArrowRight size={17} />
                </button>
              </div>
            </section>
          )}

          {step === 2 && (
            <section className="card p-6 sm:p-7">
              <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Step 2 · Media input</p>
                  <h2 className="mt-1 text-2xl font-extrabold tracking-tight">Upload a walking photo or video</h2>
                  <p className="mt-1 text-sm text-slate-500">Use a full-body side view with both legs and feet visible for the most useful angles.</p>
                </div>
                <button className="btn-secondary text-sm" onClick={loadSample}><WandSparkles size={16} /> Use sample frame</button>
              </div>

              <div
                onDragOver={(event) => event.preventDefault()}
                onDrop={onDrop}
                className="relative rounded-2xl border-2 border-dashed border-teal-200 bg-gradient-to-br from-teal-50/70 to-white px-6 py-10 text-center"
              >
                <input id="media-upload" type="file" accept="image/*,video/*" className="hidden" onChange={onFileInput} />
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-white text-teal-600 shadow-sm ring-1 ring-teal-100">
                  {processing ? <Loader2 size={26} className="animate-spin" /> : <UploadCloud size={26} />}
                </span>
                <h3 className="mt-4 text-lg font-extrabold">{processing ? "Processing media…" : "Drop your file here"}</h3>
                <p className="mx-auto mt-1 max-w-md text-sm text-slate-500">
                  JPG, PNG, WebP, MP4 or WebM · up to 40 MB. Videos are sampled into four gait frames; only compressed frames are stored.
                </p>
                <label htmlFor="media-upload" className="btn-primary mt-5 cursor-pointer">
                  <Camera size={17} /> Choose photo or video
                </label>
              </div>

              {media && (
                <div className="mt-6 space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-slate-50 px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className="grid h-9 w-9 place-items-center rounded-lg bg-white text-teal-600 ring-1 ring-slate-200">
                        {media.type === "video" ? <FileVideo2 size={18} /> : <FileImage size={18} />}
                      </span>
                      <div>
                        <p className="truncate text-sm font-bold">{media.fileName}</p>
                        <p className="text-xs text-slate-500">
                          {media.frames.length} frame{media.frames.length !== 1 ? "s" : ""}
                          {media.durationSec ? ` · ${media.durationSec.toFixed(1)}s video` : ""} · side-view analysis
                        </p>
                      </div>
                    </div>
                    <span className="chip bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"><Check size={12} /> Ready</span>
                  </div>

                  {media.type === "video" && videoUrl && (
                    <div className="grid gap-4 md:grid-cols-[1.35fr_1fr]">
                      <video ref={videoRef} src={videoUrl} controls playsInline className="w-full rounded-xl border border-slate-200 bg-black" />
                      <div className="flex flex-col justify-center rounded-xl border border-slate-200 bg-slate-50 p-4">
                        <h4 className="text-sm font-bold">Need another moment in the stride?</h4>
                        <p className="mt-1.5 text-xs leading-relaxed text-slate-500">Play or scrub the video, pause at a clear stance or swing phase, then capture that exact frame.</p>
                        <button className="btn-secondary mt-4 text-sm" onClick={captureCurrentVideoFrame}><Camera size={15} /> Capture current frame</button>
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="mb-2 flex items-center justify-between">
                      <p className="text-sm font-bold">Select a frame for keypoint marking</p>
                      <span className="text-xs font-semibold text-slate-400">Frame {media.selectedFrame + 1} of {media.frames.length}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                      {media.frames.map((frame, index) => (
                        <button
                          key={`${frame.slice(0, 32)}-${index}`}
                          type="button"
                          onClick={() => selectFrame(index)}
                          className={`overflow-hidden rounded-xl border-2 text-left transition ${media.selectedFrame === index ? "border-teal-500 ring-2 ring-teal-200" : "border-slate-200 hover:border-teal-300"}`}
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={frame} alt={`Gait frame ${index + 1}`} className="aspect-video w-full object-cover" />
                          <span className="block bg-white px-2 py-1.5 text-xs font-bold text-slate-600">Frame {index + 1}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-7 flex justify-between">
                <button className="btn-secondary" onClick={() => setStep(1)}><ArrowLeft size={17} /> Back</button>
                <button className="btn-primary" disabled={!media} onClick={() => setStep(3)}>Mark keypoints <ArrowRight size={17} /></button>
              </div>
            </section>
          )}

          {step === 3 && media && (
            <section className="card p-6 sm:p-7">
              <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Step 3 · Body keypoints</p>
                  <h2 className="mt-1 text-2xl font-extrabold tracking-tight">Mark the hip–knee–ankle chains</h2>
                  <p className="mt-1 text-sm text-slate-500">Click on the frame to place the selected point. Drag any point to fine-tune it.</p>
                </div>
                <button className="btn-secondary text-sm" onClick={autoDetect} disabled={detecting}>
                  {detecting ? <Loader2 size={16} className="animate-spin" /> : <ScanFace size={16} />}
                  {detecting ? "Running model…" : "Run local landmark model"}
                </button>
              </div>

              <div className="mb-4 flex flex-wrap items-center gap-2">
                <span className="chip bg-teal-50 text-teal-700 ring-1 ring-teal-200">
                  {activeKey ? `Placing: ${KEYPOINT_LABELS[activeKey]}` : complete ? "All keypoints placed" : "Select a point"}
                </span>
                <span className="chip bg-slate-100 text-slate-600">{keypointCount} / 6 marked</span>
                <div className="ml-auto flex gap-2">
                  <button className="btn-secondary !px-3 !py-1.5 text-xs" onClick={loadDemoLandmarks}><Sparkles size={14} /> Example points</button>
                  <button className="btn-secondary !px-3 !py-1.5 text-xs" onClick={resetAnnotation}><RotateCcw size={14} /> Clear all</button>
                </div>
              </div>

              <PoseCanvas
                src={selectedFrame}
                keypoints={keypoints}
                activeKey={activeKey}
                interactive
                onChange={handleKeypointChange}
                onAdvance={() => activeKey && advanceKeypoint(activeKey)}
                onSelectKey={setActiveKey}
                onImageLoad={(ratio) =>
                  setMedia((previous) =>
                    previous && Math.abs(previous.aspectRatio - ratio) > 0.01 ? { ...previous, aspectRatio: ratio } : previous,
                  )
                }
              />

              <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {KEYPOINT_ORDER.map((key) => {
                  const point = keypoints[key];
                  const isLeft = key.startsWith("left");
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setActiveKey(key)}
                      className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left text-sm font-bold transition ${
                        activeKey === key ? "border-teal-400 bg-teal-50" : "border-slate-200 hover:border-slate-300"
                      }`}
                    >
                      <span className={`grid h-7 w-7 place-items-center rounded-full text-xs text-white ${isLeft ? "bg-teal-500" : "bg-violet-500"}`}>
                        {point ? <Check size={14} strokeWidth={3} /> : KEYPOINT_ORDER.indexOf(key) + 1}
                      </span>
                      <span className="flex-1">{KEYPOINT_LABELS[key]}</span>
                      {point && <span className="text-[0.65rem] font-semibold text-slate-400">{(point.y * 100).toFixed(0)}% y</span>}
                    </button>
                  );
                })}
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
                <button className="btn-secondary" onClick={() => setStep(2)}><ArrowLeft size={17} /> Back</button>
                <button className="btn-primary" disabled={!complete} onClick={() => setStep(4)}>Review risk result <ArrowRight size={17} /></button>
              </div>
            </section>
          )}

          {step === 4 && media && (
            <section className="card overflow-hidden">
              <div className="border-b border-slate-100 bg-gradient-to-r from-teal-50/70 to-white px-6 py-6 sm:px-7">
                <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Step 4 · Screening result</p>
                <h2 className="mt-1 text-2xl font-extrabold tracking-tight">Osteoarthritis risk screening</h2>
                <p className="mt-1 text-sm text-slate-500">For {profile.name || "this patient"} · derived from clinical intake and one annotated gait frame.</p>
              </div>
              <div className="p-6 sm:p-7">
                <div className="flex flex-col items-center gap-6 rounded-2xl border border-slate-200 bg-slate-50/70 p-5 sm:flex-row sm:p-6">
                  <ScoreGauge score={risk.score} size={150} />
                  <div className="flex-1">
                    <RiskBadge band={risk.band} />
                    <h3 className="mt-3 text-xl font-extrabold">
                      {risk.band === "High"
                        ? "Elevated screening signal — clinician review advised"
                        : risk.band === "Moderate"
                          ? "Moderate signal — monitor and take preventive action"
                          : "Low screening signal — maintain healthy joint habits"}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600">
                      This score combines age, BMI, symptoms and history with measured knee flexion, left-right asymmetry and alignment. It is not a diagnosis.
                    </p>
                    <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-semibold text-slate-500 sm:grid-cols-4">
                      <span className="rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">BMI <b className="block text-sm text-[#102a43]">{bmi.toFixed(1)}</b></span>
                      <span className="rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">Avg flexion <b className="block text-sm text-[#102a43]">{metrics.avgFlexion.toFixed(1)}°</b></span>
                      <span className="rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">Asymmetry <b className="block text-sm text-[#102a43]">{metrics.asymmetry.toFixed(1)}°</b></span>
                      <span className="rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">Confidence <b className="block text-sm text-[#102a43]">{metrics.gaitConfidence}%</b></span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 grid gap-6 lg:grid-cols-2">
                  <div>
                    <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold"><Bone size={17} className="text-teal-600" /> Detected risk contributors</h3>
                    <ul className="space-y-2">
                      {risk.drivers.length ? risk.drivers.map((driver) => (
                        <li key={driver} className="flex gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs leading-relaxed text-slate-600">
                          <ChevronRight size={15} className="mt-0.5 shrink-0 text-amber-500" /> {driver}
                        </li>
                      )) : <li className="text-sm text-slate-500">No notable contributors were detected.</li>}
                    </ul>
                  </div>
                  <div>
                    <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold"><Sparkles size={17} className="text-teal-600" /> Suggested cautions</h3>
                    <ul className="space-y-2">
                      {risk.recommendations.map((recommendation) => (
                        <li key={recommendation} className="flex gap-2 rounded-xl border border-emerald-100 bg-emerald-50/50 px-3 py-2.5 text-xs leading-relaxed text-slate-600">
                          <Check size={15} className="mt-0.5 shrink-0 text-emerald-600" /> {recommendation}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-6 rounded-2xl border border-slate-200 p-4">
                  <p className="mb-3 text-sm font-extrabold">Annotated analysis frame</p>
                  <PoseCanvas src={selectedFrame} keypoints={keypoints} interactive={false} showLegend={false} />
                </div>

                <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-5">
                  <button className="btn-secondary" onClick={() => setStep(3)}><ArrowLeft size={17} /> Refine keypoints</button>
                  <div className="flex flex-wrap gap-2">
                    {savedId ? (
                      <>
                        <Link href={`/reports/${savedId}`} className="btn-secondary"><FileImage size={16} /> Open full report</Link>
                        <Link href="/reports" className="btn-primary">View all reports <ArrowRight size={16} /></Link>
                      </>
                    ) : (
                      <button className="btn-primary" onClick={saveReport} disabled={saving || !complete}>
                        {saving ? <Loader2 size={17} className="animate-spin" /> : <Save size={17} />}
                        {saving ? "Saving…" : "Save report"}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </section>
          )}
        </div>

        <aside className="space-y-5 xl:sticky xl:top-[90px]">
          <section className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.14em] text-teal-700">Live analysis</p>
                <h3 className="mt-1 text-lg font-extrabold">Knee mechanics</h3>
              </div>
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-teal-50 text-teal-600"><Activity size={18} /></span>
            </div>
            <div className="mt-4 flex flex-col items-center rounded-2xl bg-slate-50 py-4">
              <ScoreGauge score={risk.score} size={128} label="Provisional" />
              <div className="mt-2"><RiskBadge band={risk.band} compact /></div>
            </div>
            <div className="mt-4 space-y-2.5">
              {[
                { label: "Left knee flexion", value: `${metrics.leftFlexion.toFixed(1)}°`, color: "bg-teal-500", width: Math.min(100, (metrics.leftFlexion / 90) * 100) },
                { label: "Right knee flexion", value: `${metrics.rightFlexion.toFixed(1)}°`, color: "bg-violet-500", width: Math.min(100, (metrics.rightFlexion / 90) * 100) },
                { label: "Left-right asymmetry", value: `${metrics.asymmetry.toFixed(1)}°`, color: "bg-amber-500", width: Math.min(100, (metrics.asymmetry / 30) * 100) },
                { label: "Alignment deviation", value: `${(metrics.alignmentDeviation * 100).toFixed(1)}%`, color: "bg-rose-500", width: Math.min(100, metrics.alignmentDeviation * 500) },
              ].map((item) => (
                <div key={item.label}>
                  <div className="mb-1 flex justify-between text-xs font-semibold"><span className="text-slate-500">{item.label}</span><span>{item.value}</span></div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${item.color} transition-all`} style={{ width: `${item.width}%` }} /></div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl bg-blue-50 px-3 py-2.5 text-xs leading-relaxed text-blue-800">
              <Info size={14} className="mr-1 inline" />
              Typical swing-phase knee flexion is roughly 50–70°. A single frame is a screening sample, not a full gait cycle.
            </div>
          </section>

          <section className="card p-5">
            <h3 className="text-sm font-extrabold">Annotation quality</h3>
            <div className="mt-3 flex items-center justify-between text-xs font-semibold text-slate-500"><span>{keypointCount} of 6 landmarks</span><span>{metrics.gaitConfidence}%</span></div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-teal-500 transition-all" style={{ width: `${metrics.gaitConfidence}%` }} /></div>
            <p className="mt-3 text-xs leading-relaxed text-slate-500">
              {complete
                ? "All hip, knee and ankle points are available. Angles are ready for clinical review."
                : "Complete all six points to enable a gait-weighted risk result."}
            </p>
          </section>

          <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900">
            <div className="flex items-center gap-2 font-extrabold"><CircleAlert size={15} /> Clinical safety note</div>
            <p className="mt-2">StrideCare supports early identification only. It does not diagnose osteoarthritis or replace examination, X-ray, MRI or specialist judgement.</p>
          </section>
        </aside>
      </div>
    </div>
  );
}
