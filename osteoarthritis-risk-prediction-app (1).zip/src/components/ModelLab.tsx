"use client";

import {
  BrainCircuit,
  CheckCircle2,
  Cpu,
  Database,
  FlaskConical,
  Loader2,
  Play,
  RefreshCw,
  ScanLine,
  ShieldAlert,
  Sparkles,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import PoseCanvas from "@/components/PoseCanvas";
import { TrendSparkline } from "@/components/ui";
import {
  MASK_HEIGHT,
  MASK_WIDTH,
  trainAndTestModels,
  type ModelReport,
  type ModelWeights,
} from "@/lib/ml-core";
import { LANDMARK_MODEL, MODEL_WEIGHTS } from "@/lib/models";
import { DEMO_FRAME, KEYPOINT_ORDER, type Keypoints } from "@/lib/types";
import { inferKeypointsFromImage } from "@/lib/vision";

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not load the test frame"));
    image.src = src;
  });
}

function Metric({ label, value, suffix }: { label: string; value: string | number; suffix?: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <p className="text-[0.65rem] font-extrabold uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-2 text-2xl font-extrabold tracking-tight text-[#102a43]">{value}{suffix && <span className="ml-1 text-xs font-semibold text-slate-400">{suffix}</span>}</p>
    </div>
  );
}

export default function ModelLab({ initialReport }: { initialReport: ModelReport }) {
  const [report, setReport] = useState(initialReport);
  const [localWeights, setLocalWeights] = useState<ModelWeights | null>(null);
  const [busy, setBusy] = useState<"train" | "test" | null>(null);
  const [testPoints, setTestPoints] = useState<Keypoints>({});
  const [testConfidence, setTestConfidence] = useState<number | null>(null);
  const [mask, setMask] = useState<number[]>([]);
  const [status, setStatus] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const progress = useMemo(() => {
    const losses = report.risk.lossCurve;
    const first = losses[0] ?? 1;
    const last = losses.at(-1) ?? 0;
    const span = Math.max(first - last, 0.01);
    return losses.map((loss) => Math.round(((first - loss) / span) * 90) + 5);
  }, [report]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !mask.length) return;
    const cell = 4;
    canvas.width = MASK_WIDTH * cell;
    canvas.height = MASK_HEIGHT * cell;
    const context = canvas.getContext("2d");
    if (!context) return;
    context.fillStyle = "#0a2238";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#2dd4bf";
    mask.forEach((value, index) => {
      if (!value) return;
      const x = index % MASK_WIDTH;
      const y = Math.floor(index / MASK_WIDTH);
      context.fillRect(x * cell, y * cell, cell, cell);
    });
  }, [mask]);

  async function retrain() {
    setBusy("train");
    setStatus(null);
    await new Promise((resolve) => window.setTimeout(resolve, 40));
    try {
      const result = trainAndTestModels({
        seed: Math.floor(Date.now() % 1_000_000),
        riskSamples: 2500,
        landmarkSamples: 600,
      });
      setReport(result.report);
      setLocalWeights(result.weights);
      setStatus(`Browser retrain complete: seed ${result.report.seed}. Held-out tests were rerun; committed weights remain unchanged.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Retraining failed");
    } finally {
      setBusy(null);
    }
  }

  async function runVisualTest() {
    setBusy("test");
    setStatus(null);
    try {
      const image = await loadImage(DEMO_FRAME);
      const inference = inferKeypointsFromImage(image, localWeights?.landmarks ?? LANDMARK_MODEL);
      setTestPoints(inference.keypoints);
      setTestConfidence(inference.confidence);
      setMask(inference.mask);
      setStatus(`Local regressor produced six keypoints from a ${MASK_WIDTH}×${MASK_HEIGHT} silhouette. Segmentation confidence: ${Math.round(inference.confidence * 100)}%.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Visual test failed");
    } finally {
      setBusy(null);
    }
  }

  const confusion = report.risk.confusion;
  const maxError = Math.max(2, ...Object.values(report.landmarks.perKeypointPixelError));

  return (
    <div className="space-y-6">
      <section className="hero-glow bg-grid relative overflow-hidden rounded-3xl px-6 py-8 text-white shadow-xl sm:px-9">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="max-w-2xl">
            <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20"><BrainCircuit size={13} /> Local model lab</span>
            <h1 className="mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl">Trained here. Tested here. Inferred here.</h1>
            <p className="mt-3 text-sm leading-relaxed text-teal-50/80 sm:text-base">
              Two small models are trained from deterministic synthetic data, evaluated on held-out test sets, and shipped as local JSON weights. No external AI API, cloud inference call, or pretrained third-party model is used.
            </p>
          </div>
          <div className="rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur-md">
            <p className="text-[0.65rem] font-extrabold uppercase tracking-wider text-teal-200">Committed artifact</p>
            <p className="mt-2 text-lg font-extrabold">{MODEL_WEIGHTS.version}</p>
            <p className="mt-1 text-xs text-teal-50/75">seed {MODEL_WEIGHTS.seed}</p>
            <p className="mt-3 text-xs font-semibold text-white">{report.risk.trainSize + report.risk.testSize + report.landmarks.trainSize + report.landmarks.testSize} generated samples</p>
          </div>
        </div>
      </section>

      <section className="card flex flex-wrap items-center justify-between gap-4 p-5">
        <div>
          <h2 className="text-lg font-extrabold">Run the experiment again</h2>
          <p className="mt-1 text-xs text-slate-500">Retraining happens entirely in this browser using a fresh seed and an 80/20 held-out split.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary text-sm" onClick={retrain} disabled={busy !== null}>
            {busy === "train" ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />} Retrain & test
          </button>
          <button className="btn-primary text-sm" onClick={runVisualTest} disabled={busy !== null}>
            {busy === "test" ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />} Test on sample frame
          </button>
        </div>
      </section>

      {status && (
        <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">
          <CheckCircle2 size={18} className="mt-0.5 shrink-0" /> {status}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
        <div className="space-y-6">
          <section className="card p-5 sm:p-6">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Model 1</p>
                <h2 className="mt-1 text-xl font-extrabold">Logistic OA screening classifier</h2>
                <p className="mt-1 text-xs text-slate-500">10 standardised features · gradient descent · L2 regularisation · temperature-calibrated score</p>
              </div>
              <span className="chip bg-teal-50 text-teal-700 ring-1 ring-teal-200"><Cpu size={12} /> {report.risk.epochs} epochs</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Metric label="Held-out accuracy" value={(report.risk.accuracy * 100).toFixed(1)} suffix="%" />
              <Metric label="ROC-AUC" value={report.risk.rocAuc.toFixed(3)} />
              <Metric label="F1 score" value={report.risk.f1.toFixed(3)} />
              <Metric label="Test cases" value={report.risk.testSize} />
            </div>
            <div className="mt-6 grid gap-5 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 p-4">
                <h3 className="text-sm font-extrabold">Training loss</h3>
                <p className="mt-1 text-xs text-slate-500">Mapped to optimisation progress across recorded epochs.</p>
                <div className="mt-4"><TrendSparkline values={progress} /></div>
                <p className="mt-1 text-xs font-semibold text-slate-400">start {report.risk.lossCurve[0]?.toFixed(4)} → final {report.risk.finalLoss.toFixed(4)}</p>
              </div>
              <div className="rounded-2xl border border-slate-200 p-4">
                <h3 className="text-sm font-extrabold">Held-out confusion matrix</h3>
                <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                  {[
                    { label: "True positive", value: confusion.tp, color: "bg-emerald-50 text-emerald-700" },
                    { label: "False positive", value: confusion.fp, color: "bg-amber-50 text-amber-700" },
                    { label: "False negative", value: confusion.fn, color: "bg-rose-50 text-rose-700" },
                    { label: "True negative", value: confusion.tn, color: "bg-slate-100 text-slate-700" },
                  ].map((item) => (
                    <div key={item.label} className={`rounded-xl p-3 ${item.color}`}>
                      <p className="text-xl font-extrabold">{item.value}</p>
                      <p className="text-[0.62rem] font-bold uppercase tracking-wide">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section className="card p-5 sm:p-6">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Model 2</p>
                <h2 className="mt-1 text-xl font-extrabold">Ridge silhouette-to-keypoint regressor</h2>
                <p className="mt-1 text-xs text-slate-500">40 silhouette features · 12 coordinate outputs · closed-form normal equations</p>
              </div>
              <span className="chip bg-violet-50 text-violet-700 ring-1 ring-violet-200"><ScanLine size={12} /> {report.landmarks.testSize} test poses</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <Metric label="Mean pixel error" value={report.landmarks.meanPixelError.toFixed(2)} suffix="px" />
              <Metric label="Normalised error" value={report.landmarks.meanNormalizedError.toFixed(3)} />
              <Metric label="Ridge λ" value={report.landmarks.ridge} />
            </div>
            <div className="mt-5 space-y-2.5">
              {KEYPOINT_ORDER.map((key) => {
                const error = report.landmarks.perKeypointPixelError[key];
                return (
                  <div key={key}>
                    <div className="mb-1 flex justify-between text-xs font-semibold"><span className="text-slate-500">{key.replace(/([A-Z])/g, " $1")}</span><span>{error.toFixed(2)} px</span></div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-violet-500" style={{ width: `${(error / maxError) * 100}%` }} /></div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="card p-5 sm:p-6">
            <h2 className="text-xl font-extrabold">Visual inference test</h2>
            <p className="mt-1 text-sm text-slate-500">The local regressor reads a row-background-subtracted silhouette and predicts six landmarks. Click “Test on sample frame” to run it.</p>
            <div className="mt-5 grid gap-4 lg:grid-cols-[1.5fr_0.5fr]">
              <div>
                <PoseCanvas src={DEMO_FRAME} keypoints={testPoints} interactive={false} showLegend={Boolean(Object.keys(testPoints).length)} />
                {testConfidence !== null && <p className="mt-2 text-xs font-semibold text-teal-700">Segmentation confidence: {(testConfidence * 100).toFixed(0)}% · {Object.keys(testPoints).length}/6 landmarks inferred</p>}
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                <p className="mb-2 text-xs font-extrabold">Extracted {MASK_WIDTH}×{MASK_HEIGHT} silhouette</p>
                <canvas ref={canvasRef} className="mx-auto block max-w-full rounded-lg bg-[#0a2238]" style={{ imageRendering: "pixelated" }} />
                <p className="mt-2 text-[0.68rem] leading-relaxed text-slate-500">Row-wise border colour is subtracted from the image, then band density, centre and width become the learned model’s input features.</p>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <section className="card p-5 sm:p-6">
            <FlaskConical size={21} className="text-teal-600" />
            <h2 className="mt-3 text-lg font-extrabold">Training protocol</h2>
            <ol className="mt-4 space-y-3 text-xs leading-relaxed text-slate-600">
              <li><b className="block text-[#102a43]">1. Generate</b>{report.risk.trainSize + report.risk.testSize} synthetic intake records and {report.landmarks.trainSize + report.landmarks.testSize} silhouette poses with known landmarks.</li>
              <li><b className="block text-[#102a43]">2. Split</b>Deterministic shuffle, 80% training and 20% held-out test for each model.</li>
              <li><b className="block text-[#102a43]">3. Fit</b>Logistic gradient descent and ridge normal equations learn only from training samples.</li>
              <li><b className="block text-[#102a43]">4. Test</b>Accuracy, precision, recall, F1, ROC-AUC, confusion matrix and landmark pixel error are computed on held-out samples.</li>
              <li><b className="block text-[#102a43]">5. Ship</b>Learned coefficients are written to local JSON and loaded directly by the app.</li>
            </ol>
            <div className="mt-5 flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5 text-xs font-semibold text-slate-600"><Database size={15} className="text-teal-600" /> Artifact date: {report.generatedAt.slice(0, 10)}</div>
          </section>

          <section className="card p-5 sm:p-6">
            <div className="flex items-center gap-2"><Sparkles size={19} className="text-teal-600" /><h2 className="text-lg font-extrabold">Feature vector</h2></div>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {MODEL_WEIGHTS.risk.featureNames.map((name) => (
                <span key={name} className="chip bg-teal-50 text-teal-800 ring-1 ring-teal-100">{name}</span>
              ))}
            </div>
            <p className="mt-4 text-xs leading-relaxed text-slate-500">The model sees standardised values. Rule-based explanations and cautions shown in reports are separate from the learned score.</p>
          </section>

          <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
            <div className="flex items-center gap-2 text-sm font-extrabold text-amber-900"><ShieldAlert size={17} /> Validation boundary</div>
            <ul className="mt-3 space-y-2 text-xs leading-relaxed text-amber-900/85">
              {report.notes.map((note) => <li key={note}>• {note}</li>)}
            </ul>
            <p className="mt-4 text-xs font-bold text-amber-950">A real clinical deployment requires prospective patient data, ethics review and clinical validation.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
