"use client";

import { useState, type PointerEvent } from "react";
import {
  KEYPOINT_ORDER,
  KEYPOINT_SHORT,
  type KeypointKey,
  type Keypoints,
  type Point,
} from "@/lib/types";

type Props = {
  src: string;
  keypoints: Keypoints;
  activeKey?: KeypointKey | null;
  interactive?: boolean;
  onChange?: (key: KeypointKey, point: Point) => void;
  onAdvance?: () => void;
  onSelectKey?: (key: KeypointKey) => void;
  onImageLoad?: (aspectRatio: number) => void;
  showLegend?: boolean;
};

const connections: Array<[KeypointKey, KeypointKey, string]> = [
  ["leftHip", "leftKnee", "#2dd4bf"],
  ["leftKnee", "leftAnkle", "#2dd4bf"],
  ["rightHip", "rightKnee", "#a78bfa"],
  ["rightKnee", "rightAnkle", "#a78bfa"],
  ["leftHip", "rightHip", "#fbbf24"],
];

function clamp(value: number) {
  return Math.min(1, Math.max(0, value));
}

export default function PoseCanvas({
  src,
  keypoints,
  activeKey = null,
  interactive = false,
  onChange,
  onAdvance,
  onSelectKey,
  onImageLoad,
  showLegend = true,
}: Props) {
  const [dragging, setDragging] = useState<KeypointKey | null>(null);

  function pointFromEvent(event: PointerEvent<HTMLDivElement>): Point {
    const rect = event.currentTarget.getBoundingClientRect();
    return {
      x: clamp((event.clientX - rect.left) / rect.width),
      y: clamp((event.clientY - rect.top) / rect.height),
    };
  }

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    if (!interactive) return;
    const element = (event.target as HTMLElement).closest("[data-keypoint]");
    const key = element?.getAttribute("data-keypoint") as KeypointKey | null;
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);

    if (key && KEYPOINT_ORDER.includes(key)) {
      setDragging(key);
      onSelectKey?.(key);
      return;
    }
    if (activeKey) {
      onChange?.(activeKey, pointFromEvent(event));
      onAdvance?.();
    }
  }

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    if (!interactive || !dragging) return;
    onChange?.(dragging, pointFromEvent(event));
  }

  function stopDragging(event: PointerEvent<HTMLDivElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    setDragging(null);
  }

  return (
    <div className="relative overflow-hidden rounded-2xl bg-slate-900 shadow-inner">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt="Gait analysis frame with body keypoints"
        draggable={false}
        className="block w-full select-none"
        onLoad={(event) => {
          const image = event.currentTarget;
          if (image.naturalWidth && image.naturalHeight) {
            onImageLoad?.(image.naturalWidth / image.naturalHeight);
          }
        }}
      />

      <svg className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true">
        {connections.map(([from, to, color]) => {
          const a = keypoints[from];
          const b = keypoints[to];
          if (!a || !b) return null;
          return (
            <g key={`${from}-${to}`}>
              <line
                x1={`${a.x * 100}%`}
                y1={`${a.y * 100}%`}
                x2={`${b.x * 100}%`}
                y2={`${b.y * 100}%`}
                stroke="rgba(2, 20, 35, 0.65)"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <line
                x1={`${a.x * 100}%`}
                y1={`${a.y * 100}%`}
                x2={`${b.x * 100}%`}
                y2={`${b.y * 100}%`}
                stroke={color}
                strokeWidth="3.5"
                strokeLinecap="round"
              />
            </g>
          );
        })}
      </svg>

      <div
        className={`absolute inset-0 ${interactive ? "cursor-crosshair touch-none" : "pointer-events-none"}`}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={stopDragging}
        onPointerCancel={stopDragging}
        onLostPointerCapture={() => setDragging(null)}
      >
        {KEYPOINT_ORDER.map((key) => {
          const point = keypoints[key];
          if (!point) return null;
          const isLeft = key.startsWith("left");
          const color = isLeft ? "#14b8a6" : "#8b5cf6";
          const active = activeKey === key;
          return (
            <button
              key={key}
              type="button"
              data-keypoint={key}
              aria-label={`${key} landmark`}
              className={`absolute grid h-7 w-7 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-white text-[0.58rem] font-black text-white shadow-lg transition ${
                active ? "z-10 scale-125 ring-4 ring-white/50" : ""
              } ${interactive ? "cursor-grab active:cursor-grabbing" : "pointer-events-none"}`}
              style={{ left: `${point.x * 100}%`, top: `${point.y * 100}%`, background: color }}
            >
              {KEYPOINT_SHORT[key]}
            </button>
          );
        })}
      </div>

      {showLegend && (
        <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-3 rounded-lg bg-slate-950/72 px-3 py-2 text-[0.65rem] font-bold text-white backdrop-blur-sm">
          <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-teal-400" /> Left chain</span>
          <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-violet-400" /> Right chain</span>
        </div>
      )}
      {interactive && activeKey && (
        <div className="pointer-events-none absolute right-3 top-3 rounded-lg bg-slate-950/72 px-3 py-2 text-[0.68rem] font-bold text-white backdrop-blur-sm">
          Click to place · drag to refine
        </div>
      )}
    </div>
  );
}
