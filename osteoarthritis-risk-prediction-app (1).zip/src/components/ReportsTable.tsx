"use client";

import {
  ArrowRight,
  Download,
  FileImage,
  FileVideo2,
  Filter,
  Search,
  ShieldAlert,
} from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { RiskBadge, StatusPill, formatDate } from "@/components/ui";
import type { DoctorStatus, MediaType, RiskBand } from "@/lib/types";

export type ReportRow = {
  id: number;
  patientName: string;
  age: number;
  sex: string;
  score: number;
  band: RiskBand;
  doctorStatus: DoctorStatus;
  createdAt: string;
  mediaType: MediaType;
  fileName: string;
  avgFlexion: number;
  asymmetry: number;
};

export default function ReportsTable({ rows }: { rows: ReportRow[] }) {
  const [query, setQuery] = useState("");
  const [band, setBand] = useState<RiskBand | "all">("all");
  const [status, setStatus] = useState<DoctorStatus | "all">("all");

  const filtered = useMemo(() => {
    const search = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesQuery =
        !search ||
        row.patientName.toLowerCase().includes(search) ||
        row.fileName.toLowerCase().includes(search) ||
        String(row.id).includes(search);
      return matchesQuery && (band === "all" || row.band === band) && (status === "all" || row.doctorStatus === status);
    });
  }, [rows, query, band, status]);

  const avgScore = rows.length ? Math.round(rows.reduce((sum, row) => sum + row.score, 0) / rows.length) : 0;
  const high = rows.filter((row) => row.band === "High").length;
  const pending = rows.filter((row) => row.doctorStatus === "Pending review").length;

  function exportCsv() {
    const escape = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const header = ["ID", "Patient", "Age", "Sex", "Date", "Media", "Score", "Band", "Avg flexion", "Asymmetry", "Status"];
    const lines = filtered.map((row) =>
      [row.id, row.patientName, row.age, row.sex, formatDate(row.createdAt), row.mediaType, row.score, row.band, row.avgFlexion, row.asymmetry, row.doctorStatus]
        .map(escape)
        .join(","),
    );
    const blob = new Blob([[header.map(escape).join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "stridecare-assessments.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <section className="hero-glow bg-grid flex flex-wrap items-center justify-between gap-5 rounded-3xl px-6 py-7 text-white shadow-xl sm:px-8">
        <div>
          <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-200">Reports library</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight">Every screening, in one longitudinal view</h1>
          <p className="mt-2 max-w-2xl text-sm text-teal-50/80">Search, filter and export assessments, then open a case for clinician review or a patient-friendly summary.</p>
        </div>
        <button onClick={exportCsv} className="btn-secondary !border-white/25 !bg-white/10 !text-white hover:!bg-white/16">
          <Download size={16} /> Export CSV
        </button>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Saved reports", value: rows.length, icon: FileImage },
          { label: "Average score", value: avgScore, icon: Filter },
          { label: "High-risk cases", value: high, icon: ShieldAlert },
          { label: "Pending reviews", value: pending, icon: ArrowRight },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="card flex items-center justify-between p-5">
              <div><p className="text-xs font-bold uppercase tracking-wide text-slate-400">{item.label}</p><p className="mt-2 text-3xl font-extrabold">{item.value}</p></div>
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-teal-50 text-teal-600"><Icon size={19} /></span>
            </div>
          );
        })}
      </section>

      <section className="card overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4 sm:p-5">
          <div className="relative min-w-[220px] flex-1">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input !pl-9" placeholder="Search by patient, file or report ID" value={query} onChange={(event) => setQuery(event.target.value)} />
          </div>
          <select className="input w-auto min-w-[150px]" value={band} onChange={(event) => setBand(event.target.value as RiskBand | "all")}>
            <option value="all">All risk bands</option><option value="Low">Low</option><option value="Moderate">Moderate</option><option value="High">High</option>
          </select>
          <select className="input w-auto min-w-[170px]" value={status} onChange={(event) => setStatus(event.target.value as DoctorStatus | "all")}>
            <option value="all">All statuses</option><option value="Pending review">Pending review</option><option value="Reviewed">Reviewed</option><option value="Follow-up">Follow-up</option>
          </select>
          <span className="text-xs font-semibold text-slate-400">{filtered.length} result{filtered.length !== 1 ? "s" : ""}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[880px] text-left">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/60 text-[0.68rem] font-extrabold uppercase tracking-wider text-slate-400">
                <th className="px-5 py-3">Report / patient</th><th className="px-4 py-3">Source</th><th className="px-4 py-3">Avg flexion</th><th className="px-4 py-3">Risk score</th><th className="px-4 py-3">Risk band</th><th className="px-4 py-3">Clinical status</th><th className="px-4 py-3">Date</th><th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/70">
                  <td className="px-5 py-4">
                    <p className="text-sm font-extrabold">{row.patientName}</p>
                    <p className="text-xs text-slate-400">#{String(row.id).padStart(4, "0")} · {row.age} yrs · {row.sex}</p>
                  </td>
                  <td className="px-4 py-4 text-xs font-semibold capitalize text-slate-500">
                    <span className="inline-flex items-center gap-1.5">{row.mediaType === "video" ? <FileVideo2 size={14} /> : <FileImage size={14} />}{row.mediaType}</span>
                  </td>
                  <td className="px-4 py-4 text-sm font-bold">{row.avgFlexion.toFixed(1)}°</td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2"><span className="w-7 text-sm font-extrabold">{row.score}</span><div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${row.band === "High" ? "bg-rose-500" : row.band === "Moderate" ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${row.score}%` }} /></div></div>
                  </td>
                  <td className="px-4 py-4"><RiskBadge band={row.band} compact /></td>
                  <td className="px-4 py-4"><StatusPill status={row.doctorStatus} /></td>
                  <td className="px-4 py-4 text-xs font-semibold text-slate-500">{formatDate(row.createdAt)}</td>
                  <td className="px-5 py-4 text-right"><Link href={`/reports/${row.id}`} className="btn-secondary !px-3 !py-1.5 text-xs">Open <ArrowRight size={13} /></Link></td>
                </tr>
              ))}
              {!filtered.length && (
                <tr><td colSpan={8} className="px-5 py-12 text-center text-sm text-slate-500">No reports match these filters. Try a broader search.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
