import { AlertTriangle, CheckCircle2, Clock3, ShieldAlert } from "lucide-react";
import type { DoctorStatus, RiskBand } from "@/lib/types";

export function scoreColor(score: number) {
  if (score >= 60) return "#e11d48";
  if (score >= 30) return "#f59e0b";
  return "#10b981";
}

export function bandClasses(band: RiskBand) {
  if (band === "High") return "bg-rose-50 text-rose-700 ring-rose-200";
  if (band === "Moderate") return "bg-amber-50 text-amber-700 ring-amber-200";
  return "bg-emerald-50 text-emerald-700 ring-emerald-200";
}

export function RiskBadge({ band, compact = false }: { band: RiskBand; compact?: boolean }) {
  const Icon = band === "High" ? ShieldAlert : band === "Moderate" ? AlertTriangle : CheckCircle2;
  return (
    <span className={`chip ring-1 ${bandClasses(band)}`}>
      <Icon size={compact ? 12 : 13} />
      {band} {compact ? "" : "risk"}
    </span>
  );
}

export function StatusPill({ status }: { status: DoctorStatus }) {
  const styles =
    status === "Reviewed"
      ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
      : status === "Follow-up"
        ? "bg-indigo-50 text-indigo-700 ring-indigo-200"
        : "bg-slate-100 text-slate-600 ring-slate-200";
  const Icon = status === "Reviewed" ? CheckCircle2 : status === "Follow-up" ? AlertTriangle : Clock3;
  return (
    <span className={`chip ring-1 ${styles}`}>
      <Icon size={12} /> {status}
    </span>
  );
}

export function ScoreGauge({
  score,
  size = 150,
  label = "OA risk score",
}: {
  score: number;
  size?: number;
  label?: string;
}) {
  const stroke = 12;
  const radius = (size - stroke - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(100, Math.max(0, score)) / 100) * circumference;
  const color = scoreColor(score);
  return (
    <div className="relative grid shrink-0 place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-label={`${label}: ${score} out of 100`}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#e9eff5" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.7s ease" }}
        />
      </svg>
      <div className="absolute text-center">
        <div className="text-[2rem] font-extrabold leading-none tracking-tight" style={{ color }}>
          {score}
        </div>
        <div className="mt-1 text-[0.65rem] font-bold uppercase tracking-[0.12em] text-slate-400">/ 100</div>
        <div className="mt-1 text-[0.66rem] font-semibold text-slate-500">{label}</div>
      </div>
    </div>
  );
}

export function TrendSparkline({ values, height = 72 }: { values: number[]; height?: number }) {
  const safe = values.length ? values : [0];
  const max = Math.max(100, ...safe);
  const points = safe
    .map((value, index) => {
      const x = safe.length === 1 ? 50 : (index / (safe.length - 1)) * 100;
      const y = height - 8 - (value / max) * (height - 20);
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" className="h-[72px] w-full">
      <defs>
        <linearGradient id="trend-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#14b8a6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1="0" y1={height - 8} x2="100" y2={height - 8} stroke="#e2e8f0" strokeWidth="0.7" />
      <polygon points={`0,${height - 8} ${points} 100,${height - 8}`} fill="url(#trend-fill)" />
      <polyline points={points} fill="none" stroke="#0d9488" strokeWidth="2" vectorEffect="non-scaling-stroke" />
      {safe.map((value, index) => {
        const x = safe.length === 1 ? 50 : (index / (safe.length - 1)) * 100;
        const y = height - 8 - (value / max) * (height - 20);
        return <circle key={index} cx={x} cy={y} r="1.5" fill="#0d9488" />;
      })}
    </svg>
  );
}

export function formatDate(iso: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(iso));
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && (
          <p className="mb-1 text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">{eyebrow}</p>
        )}
        <h2 className="text-xl font-extrabold tracking-tight text-[#102a43]">{title}</h2>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}
