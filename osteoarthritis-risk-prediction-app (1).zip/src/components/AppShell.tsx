"use client";

import {
  Activity,
  BookOpen,
  BrainCircuit,
  ChevronRight,
  ClipboardList,
  FileBarChart2,
  LayoutDashboard,
  Menu,
  Plus,
  ScanLine,
  ShieldCheck,
  Stethoscope,
  X,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";

const navigation = [
  { href: "/", label: "Overview", icon: LayoutDashboard, exact: true },
  { href: "/assess", label: "New assessment", icon: ScanLine, exact: false },
  { href: "/reports", label: "Reports", icon: FileBarChart2, exact: false },
  { href: "/models", label: "Model lab", icon: BrainCircuit, exact: false },
  { href: "/guide", label: "Patient guide", icon: BookOpen, exact: false },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (item: (typeof navigation)[number]) =>
    item.exact ? pathname === item.href : pathname.startsWith(item.href);

  const pageTitle =
    pathname === "/"
      ? "Clinical overview"
      : pathname.startsWith("/assess")
        ? "Gait assessment studio"
        : pathname.startsWith("/reports")
          ? "Assessment reports"
          : pathname.startsWith("/models")
            ? "Local model lab"
            : "Patient prevention guide";

  const navContent = (
    <>
      <Link href="/" className="flex items-center gap-3 px-2 py-1" onClick={() => setMobileOpen(false)}>
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-teal-400 to-cyan-600 text-white shadow-lg shadow-teal-900/20">
          <Activity size={21} strokeWidth={2.5} />
        </span>
        <span>
          <span className="block text-[1.05rem] font-extrabold tracking-tight text-white">StrideCare</span>
          <span className="block text-[0.66rem] font-semibold uppercase tracking-[0.16em] text-teal-200/80">Gait intelligence</span>
        </span>
      </Link>

      <div className="mt-9 px-3 text-[0.67rem] font-bold uppercase tracking-[0.16em] text-slate-500">Workspace</div>
      <nav className="mt-3 space-y-1.5">
        {navigation.map((item) => {
          const Icon = item.icon;
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold transition ${
                active
                  ? "bg-teal-400/14 text-teal-200 ring-1 ring-teal-300/20"
                  : "text-slate-300 hover:bg-white/6 hover:text-white"
              }`}
            >
              <Icon size={18} />
              <span className="flex-1">{item.label}</span>
              {active && <ChevronRight size={15} className="text-teal-300" />}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto rounded-2xl border border-white/10 bg-white/6 p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <ShieldCheck size={17} className="text-teal-300" /> Screening support
        </div>
        <p className="mt-2 text-xs leading-relaxed text-slate-300">
          Decision support only. A clinician must confirm findings with examination and appropriate imaging.
        </p>
      </div>
      <div className="mt-5 flex items-center gap-3 border-t border-white/10 px-2 pt-5">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-teal-500/20 text-teal-200">
          <Stethoscope size={17} />
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-bold text-white">Dr. A. Verma</p>
          <p className="truncate text-xs text-slate-400">Orthopaedic screening</p>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#f4f7fb]">
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-[250px] flex-col bg-[#0a2238] px-4 py-6 lg:flex">
        {navContent}
      </aside>

      {mobileOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden">
          <button
            aria-label="Close navigation"
            className="absolute inset-0 bg-slate-950/55"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 flex w-[270px] flex-col bg-[#0a2238] px-4 py-6">
            <button
              aria-label="Close navigation"
              className="absolute right-3 top-5 text-slate-300"
              onClick={() => setMobileOpen(false)}
            >
              <X size={20} />
            </button>
            {navContent}
          </aside>
        </div>
      )}

      <div className="lg:pl-[250px]">
        <header className="no-print sticky top-0 z-20 border-b border-slate-200/80 bg-white/88 backdrop-blur-xl">
          <div className="mx-auto flex h-[72px] max-w-[1500px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3">
              <button
                className="grid h-9 w-9 place-items-center rounded-lg border border-slate-200 lg:hidden"
                onClick={() => setMobileOpen(true)}
                aria-label="Open navigation"
              >
                <Menu size={19} />
              </button>
              <div>
                <p className="text-[0.68rem] font-bold uppercase tracking-[0.14em] text-teal-700">Knee health platform</p>
                <h1 className="text-lg font-extrabold tracking-tight text-[#102a43]">{pageTitle}</h1>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <span className="hidden items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 ring-1 ring-emerald-200 sm:inline-flex">
                <span className="pulse-dot h-2 w-2 rounded-full bg-emerald-500" /> Secure workspace
              </span>
              <span className="hidden h-9 items-center gap-2 rounded-full border border-slate-200 px-3 text-xs font-semibold text-slate-600 md:inline-flex">
                <ClipboardList size={15} /> Clinician mode
              </span>
              <Link href="/assess" className="btn-primary !px-3.5 !py-2 text-sm">
                <Plus size={16} /> <span className="hidden sm:inline">New assessment</span>
              </Link>
            </div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1500px] px-4 py-7 sm:px-6 lg:px-8 print-full">
          {children}
        </main>
      </div>
    </div>
  );
}
