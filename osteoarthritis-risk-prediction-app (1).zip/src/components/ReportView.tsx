"use client";

import {
  Activity,
  ArrowLeft,
  Bone,
  CalendarDays,
  Check,
  CircleAlert,
  ClipboardCheck,
  FileImage,
  HeartHandshake,
  Info,
  Loader2,
  Printer,
  Save,
  Stethoscope,
  UserRound,
} from "lucide-react";
import { reviewAssessment } from "@/app/actions";
import Link from "next/link";
import { useState } from "react";
import PoseCanvas from "@/components/PoseCanvas";
import { RiskBadge, ScoreGauge, StatusPill, formatDate } from "@/components/ui";
import {
  DEMO_FRAME,
  type AssessmentRecord,
  type DoctorStatus,
} from "@/lib/types";

type Tab = "doctor" | "patient";

function angleInterpretation(band: AssessmentRecord["band"]) {
  if (band === "High") {
    return "Several risk markers are present. A clinician should review your symptoms, examine the knee and decide whether imaging or treatment is needed.";
  }
  if (band === "Moderate") {
    return "Some markers deserve attention. Preventive habits and a follow-up check can help you stay ahead of symptoms.";
  }
  return "Few risk markers were found in this screening. Keep active, maintain a healthy weight and repeat the check if symptoms change.";
}

function FlexionBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-xl border border-slate-200 p-3">
      <div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold text-slate-600">{label}</span><span className="text-sm font-extrabold">{value.toFixed(1)}°</span></div>
      <div className="relative h-2.5 overflow-hidden rounded-full bg-slate-100">
        <div className="absolute inset-y-0 left-[55.5%] w-[22.2%] bg-teal-100" />
        <div className={`absolute inset-y-0 left-0 rounded-full ${color}`} style={{ width: `${Math.min(100, (value / 90) * 100)}%` }} />
      </div>
      <p className="mt-2 text-[0.65rem] font-semibold text-slate-400">Shaded band: typical 50–70° swing-phase reference</p>
    </div>
  );
}

export default function ReportView({ record }: { record: AssessmentRecord }) {
  const [tab, setTab] = useState<Tab>("doctor");
  const [current, setCurrent] = useState(record);
  const [status, setStatus] = useState<DoctorStatus>(record.doctorStatus);
  const [notes, setNotes] = useState(record.doctorNotes);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const frameSrc = current.media.frames[current.media.selectedFrame] ?? DEMO_FRAME;
  const metrics = current.metrics;

  async function saveReview() {
    setSaving(true);
    setMessage(null);
    try {
      const updated = await reviewAssessment(current.id, status, notes);
      setCurrent(updated);
      setMessage({ type: "success", text: "Clinical review saved and shared with the patient view." });
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Could not save this review" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <Link href="/reports" className="btn-secondary text-sm"><ArrowLeft size={16} /> Back to reports</Link>
        <button onClick={() => window.print()} className="btn-secondary text-sm"><Printer size={16} /> Print / save PDF</button>
      </div>

      <section className="hero-glow bg-grid print-plain rounded-3xl px-6 py-7 text-white shadow-xl sm:px-8">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20">Report #{String(current.id).padStart(4, "0")}</span>
              <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20"><CalendarDays size={12} /> {formatDate(current.createdAt)}</span>
              <StatusPill status={current.doctorStatus} />
            </div>
            <h1 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">{current.patient.name}</h1>
            <p className="mt-2 text-sm text-teal-50/80">
              {current.patient.age} years · {current.patient.sex} · BMI {current.risk.bmi.toFixed(1)} · {current.media.type === "video" ? "video frame analysis" : "photo frame analysis"}
            </p>
          </div>
          <div className="flex items-center gap-5 rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur-md">
            <ScoreGauge score={current.score} size={116} label="OA screening" />
            <div>
              <RiskBadge band={current.band} />
              <p className="mt-3 max-w-[180px] text-xs leading-relaxed text-teal-50/80">Screening estimate from intake and one annotated gait frame.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="no-print flex w-fit rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
        <button
          onClick={() => setTab("doctor")}
          className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-bold transition ${tab === "doctor" ? "bg-[#0a2238] text-white" : "text-slate-500 hover:bg-slate-50"}`}
        >
          <Stethoscope size={16} /> Clinician view
        </button>
        <button
          onClick={() => setTab("patient")}
          className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-bold transition ${tab === "patient" ? "bg-teal-600 text-white" : "text-slate-500 hover:bg-slate-50"}`}
        >
          <HeartHandshake size={16} /> Patient view
        </button>
      </div>

      {tab === "doctor" ? (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(310px,0.65fr)]">
          <div className="space-y-6">
            <section className="card print-plain p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Evidence frame</p>
                  <h2 className="mt-1 text-xl font-extrabold">Annotated hip–knee–ankle chains</h2>
                </div>
                <span className="chip bg-slate-100 text-slate-600"><FileImage size={12} /> {current.media.fileName}</span>
              </div>
              <PoseCanvas src={frameSrc} keypoints={current.keypoints} interactive={false} />
              <p className="mt-3 text-xs leading-relaxed text-slate-500">
                Keypoints are stored in frame-normalised coordinates. Knee flexion is calculated as 180° minus the hip–knee–ankle internal angle, corrected for frame aspect ratio.
              </p>
            </section>

            <section className="card print-plain p-5 sm:p-6">
              <div className="mb-5 flex items-start justify-between gap-3">
                <div>
                  <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Kinematic markers</p>
                  <h2 className="mt-1 text-xl font-extrabold">Measured knee mechanics</h2>
                </div>
                <Bone size={21} className="text-teal-600" />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <FlexionBar label="Left knee flexion" value={metrics.leftFlexion} color="bg-teal-500" />
                <FlexionBar label="Right knee flexion" value={metrics.rightFlexion} color="bg-violet-500" />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { label: "Mean flexion", value: `${metrics.avgFlexion.toFixed(1)}°` },
                  { label: "Asymmetry", value: `${metrics.asymmetry.toFixed(1)}°` },
                  { label: "Alignment dev.", value: `${(metrics.alignmentDeviation * 100).toFixed(1)}%` },
                  { label: "Stride spread", value: `${(metrics.strideSpread * 100).toFixed(0)}%` },
                ].map((item) => (
                  <div key={item.label} className="rounded-xl bg-slate-50 p-3">
                    <p className="text-[0.65rem] font-bold uppercase tracking-wide text-slate-400">{item.label}</p>
                    <p className="mt-1 text-lg font-extrabold">{item.value}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex gap-2 rounded-xl bg-blue-50 px-3 py-3 text-xs leading-relaxed text-blue-900">
                <Info size={15} className="mt-0.5 shrink-0" />
                A single frame cannot capture the full gait cycle. Use repeated, similarly framed assessments to interpret trends.
              </div>
            </section>

            <section className="card print-plain p-5 sm:p-6">
              <h2 className="text-lg font-extrabold">Risk contributors</h2>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {current.drivers.map((driver) => (
                  <div key={driver} className="flex gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs leading-relaxed text-slate-600">
                    <CircleAlert size={15} className="mt-0.5 shrink-0 text-amber-500" /> {driver}
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-extrabold uppercase tracking-wide text-slate-400">Intake note</p>
                <p className="mt-2 text-sm text-slate-600">{current.patient.notes || "No additional intake notes were recorded."}</p>
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold text-slate-500">
                  <span className="chip bg-white ring-1 ring-slate-200">Pain {current.patient.painLevel}/10</span>
                  <span className="chip bg-white ring-1 ring-slate-200">Activity: {current.patient.activityLevel}</span>
                  <span className="chip bg-white ring-1 ring-slate-200">Stiffness: {current.patient.morningStiffness ? "yes" : "no"}</span>
                  <span className="chip bg-white ring-1 ring-slate-200">Prior injury: {current.patient.priorInjury ? "yes" : "no"}</span>
                </div>
              </div>
            </section>
          </div>

          <div className="space-y-6">
            <section className="card print-plain p-5 sm:p-6">
              <div className="flex items-start gap-4">
                <ScoreGauge score={current.score} size={108} label="Risk score" />
                <div>
                  <RiskBadge band={current.band} />
                  <p className="mt-3 text-xs leading-relaxed text-slate-500">
                    {current.band === "High"
                      ? "Elevated marker burden. Prioritise clinical correlation and follow-up."
                      : current.band === "Moderate"
                        ? "Moderate marker burden. Preventive counselling and trend monitoring."
                        : "Low marker burden. Reinforce preventive habits."}
                  </p>
                </div>
              </div>
              <div className="mt-5 space-y-2 border-t border-slate-100 pt-4 text-xs">
                <div className="flex justify-between"><span className="text-slate-500">BMI</span><b>{current.risk.bmi.toFixed(1)} kg/m²</b></div>
                <div className="flex justify-between"><span className="text-slate-500">Learned model output</span><b>{((current.risk.probability ?? current.score / 100) * 100).toFixed(0)}%</b></div>
                <div className="flex justify-between"><span className="text-slate-500">Landmark confidence</span><b>{metrics.gaitConfidence}%</b></div>
                <div className="flex justify-between"><span className="text-slate-500">Media source</span><b className="capitalize">{current.media.type}</b></div>
                {current.media.durationSec && <div className="flex justify-between"><span className="text-slate-500">Video duration</span><b>{current.media.durationSec.toFixed(1)}s</b></div>}
              </div>
            </section>

            <section className="card no-print p-5 sm:p-6">
              <div className="flex items-center gap-2"><ClipboardCheck size={19} className="text-teal-600" /><h2 className="text-lg font-extrabold">Doctor review</h2></div>
              <p className="mt-1 text-xs text-slate-500">Save a status and guidance for the patient-facing summary.</p>
              {message && (
                <div className={`mt-4 rounded-xl px-3 py-2.5 text-xs font-semibold ${message.type === "success" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{message.text}</div>
              )}
              <label className="label mt-4" htmlFor="review-status">Review status</label>
              <select id="review-status" className="input" value={status} onChange={(event) => setStatus(event.target.value as DoctorStatus)}>
                <option value="Pending review">Pending review</option><option value="Reviewed">Reviewed</option><option value="Follow-up">Follow-up</option>
              </select>
              <label className="label mt-4" htmlFor="review-notes">Clinical notes & instructions</label>
              <textarea id="review-notes" rows={6} className="input resize-none" value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Findings, cautions, exercises, referral or follow-up interval" />
              <button className="btn-primary mt-4 w-full" onClick={saveReview} disabled={saving}>
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {saving ? "Saving…" : "Save clinical review"}
              </button>
            </section>

            <section className="card print-plain p-5 sm:p-6">
              <h2 className="text-sm font-extrabold">Printed clinician note</h2>
              <p className="mt-3 whitespace-pre-wrap rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
                {current.doctorNotes || "No clinician notes have been saved yet."}
              </p>
              <p className="mt-3 text-xs font-semibold text-slate-400">{current.doctorStatus}{current.reviewedAt ? ` · ${formatDate(current.reviewedAt)}` : ""}</p>
            </section>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <section className="card print-plain overflow-hidden">
            <div className="grid gap-6 p-6 sm:p-8 lg:grid-cols-[190px_1fr]">
              <div className="flex justify-center"><ScoreGauge score={current.score} size={170} label="Your knee score" /></div>
              <div>
                <span className="chip bg-teal-50 text-teal-700 ring-1 ring-teal-200"><HeartHandshake size={13} /> Your plain-language summary</span>
                <h2 className="mt-4 text-2xl font-extrabold tracking-tight">
                  {current.band === "High" ? "It’s worth getting this checked soon" : current.band === "Moderate" ? "A good time to build knee-protective habits" : "Your screening looks reassuring"}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">{angleInterpretation(current.band)}</p>
                <div className="mt-5 flex flex-wrap gap-2"><RiskBadge band={current.band} /><span className="chip bg-slate-100 text-slate-600"><UserRound size={12} /> Prepared for {current.patient.name}</span><span className="chip bg-slate-100 text-slate-600"><CalendarDays size={12} /> {formatDate(current.createdAt)}</span></div>
                <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900">
                  <b>Important:</b> this is a screening check, not a diagnosis. Only your clinician can interpret your symptoms and decide whether tests or treatment are needed.
                </div>
              </div>
            </div>
          </section>

          <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
            <section className="card print-plain p-5 sm:p-6">
              <h2 className="text-xl font-extrabold">What we looked at</h2>
              <p className="mt-1 text-sm text-slate-500">A walking frame helps show how comfortably each knee bends and whether the two sides move similarly.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                {[
                  { label: "Left knee bend", value: `${metrics.leftFlexion.toFixed(0)}°`, text: "How much the left knee flexes in this frame." },
                  { label: "Right knee bend", value: `${metrics.rightFlexion.toFixed(0)}°`, text: "How much the right knee flexes in this frame." },
                  { label: "Side difference", value: `${metrics.asymmetry.toFixed(0)}°`, text: "A large difference can suggest uneven loading." },
                ].map((item) => (
                  <div key={item.label} className="rounded-2xl border border-slate-200 p-4">
                    <Activity size={18} className="text-teal-600" />
                    <p className="mt-3 text-2xl font-extrabold">{item.value}</p>
                    <p className="mt-1 text-xs font-bold">{item.label}</p>
                    <p className="mt-1 text-xs leading-relaxed text-slate-500">{item.text}</p>
                  </div>
                ))}
              </div>
              <div className="mt-5 overflow-hidden rounded-2xl border border-slate-200">
                <PoseCanvas src={frameSrc} keypoints={current.keypoints} interactive={false} showLegend={false} />
              </div>
              <p className="mt-3 text-xs text-slate-500">The coloured dots mark the hip, knee and ankle points used for the measurements.</p>
            </section>

            <div className="space-y-6">
              <section className="card print-plain p-5 sm:p-6">
                <h2 className="text-lg font-extrabold">Your caution plan</h2>
                <ul className="mt-4 space-y-3">
                  {current.recommendations.map((recommendation, index) => (
                    <li key={recommendation} className="flex gap-3 rounded-xl border border-emerald-100 bg-emerald-50/50 px-3 py-3">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-500 text-[0.65rem] font-extrabold text-white">{index + 1}</span>
                      <span className="text-xs leading-relaxed text-slate-600">{recommendation}</span>
                    </li>
                  ))}
                </ul>
              </section>

              <section className="card print-plain p-5 sm:p-6">
                <div className="flex items-center gap-2"><Stethoscope size={19} className="text-teal-600" /><h2 className="text-lg font-extrabold">Note from your clinician</h2></div>
                <p className="mt-3 whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm leading-relaxed text-slate-600">
                  {current.doctorNotes || "Your clinician has not added a personal note yet. Ask for one at your next appointment."}
                </p>
                <div className="mt-3"><StatusPill status={current.doctorStatus} /></div>
              </section>
            </div>
          </div>

          <section className="rounded-2xl border border-teal-200 bg-teal-50 p-5 sm:p-6">
            <h2 className="flex items-center gap-2 text-lg font-extrabold text-[#0b4b4d]"><Check size={19} /> Three simple next steps</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                "Keep a short diary of pain, stiffness and walking distance.",
                "Choose low-impact movement and build strength gradually.",
                "Repeat the same walking check in 4–6 weeks to see the trend.",
              ].map((item, index) => (
                <div key={item} className="rounded-xl bg-white/75 p-4 text-xs leading-relaxed text-teal-900/80">
                  <b className="mb-2 block text-sm text-teal-800">0{index + 1}</b>{item}
                </div>
              ))}
            </div>
            <Link href="/guide" className="no-print mt-5 inline-flex items-center gap-2 text-sm font-extrabold text-teal-800">Open the full prevention guide <ArrowLeft size={15} className="rotate-180" /></Link>
          </section>
        </div>
      )}

      <p className="pb-3 text-center text-[0.68rem] leading-relaxed text-slate-400">
        StrideCare screening output · Not a medical diagnosis · Confirm findings with a qualified healthcare professional.
      </p>
    </div>
  );
}
