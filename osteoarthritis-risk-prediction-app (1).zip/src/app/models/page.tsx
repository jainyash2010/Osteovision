import AppShell from "@/components/AppShell";
import ModelLab from "@/components/ModelLab";
import { MODEL_REPORT } from "@/lib/models";

export const metadata = {
  title: "Local model lab | StrideCare",
  description: "Train, test and inspect the local logistic screening and ridge landmark models.",
};

export default function ModelsPage() {
  return (
    <AppShell>
      <ModelLab initialReport={MODEL_REPORT} />
    </AppShell>
  );
}
