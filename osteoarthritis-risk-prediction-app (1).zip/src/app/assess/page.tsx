import AppShell from "@/components/AppShell";
import AssessmentStudio from "@/components/AssessmentStudio";

export const metadata = {
  title: "New gait assessment | StrideCare",
};

export default function AssessPage() {
  return (
    <AppShell>
      <AssessmentStudio />
    </AppShell>
  );
}
