import {
  Activity,
  CalendarCheck2,
  Camera,
  CircleAlert,
  Footprints,
  HeartPulse,
  Scale,
  ShieldCheck,
  Stethoscope,
  TriangleAlert,
} from "lucide-react";
import Link from "next/link";
import AppShell from "@/components/AppShell";

export const metadata = {
  title: "Patient prevention guide | StrideCare",
};

const habits = [
  {
    icon: Scale,
    title: "Reduce avoidable joint load",
    text: "Even a modest, gradual weight reduction can lower the force passing through the knees during each step.",
  },
  {
    icon: HeartPulse,
    title: "Move little and often",
    text: "Walking, cycling, swimming and gentle mobility work help nourish cartilage without high-impact stress.",
  },
  {
    icon: Activity,
    title: "Strengthen the support muscles",
    text: "Quadriceps, hamstring, hip and calf strength improve shock absorption and knee control.",
  },
  {
    icon: Footprints,
    title: "Check footwear and surface",
    text: "Supportive shoes and avoiding repeated hard-surface impact can reduce irritating asymmetrical loading.",
  },
];

export default function GuidePage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <section className="hero-glow bg-grid rounded-3xl px-6 py-9 text-white shadow-xl sm:px-9">
          <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20"><ShieldCheck size={13} /> Patient-friendly guidance</span>
          <h1 className="mt-5 max-w-3xl text-3xl font-extrabold tracking-tight sm:text-4xl">Small steps now can protect your knees later.</h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-teal-50/80 sm:text-base">
            Osteoarthritis develops gradually. A gait screening does not diagnose it, but it can highlight changes worth discussing early — when preventive habits have the most impact.
          </p>
          <Link href="/assess" className="btn-primary mt-6 !bg-white !text-[#0b5f61] !shadow-none hover:!bg-teal-50">
            Start a screening <Camera size={17} />
          </Link>
        </section>

        <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
          <section className="card p-6 sm:p-7">
            <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Everyday prevention</p>
            <h2 className="mt-1 text-2xl font-extrabold">Four habits with the strongest payoff</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {habits.map((habit) => {
                const Icon = habit.icon;
                return (
                  <div key={habit.title} className="rounded-2xl border border-slate-200 p-4">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-teal-50 text-teal-700"><Icon size={19} /></span>
                    <h3 className="mt-3 text-sm font-extrabold">{habit.title}</h3>
                    <p className="mt-1.5 text-xs leading-relaxed text-slate-500">{habit.text}</p>
                  </div>
                );
              })}
            </div>

            <div className="mt-7 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
                <h3 className="flex items-center gap-2 text-sm font-extrabold text-emerald-900"><ShieldCheck size={17} /> Usually helpful</h3>
                <ul className="mt-3 space-y-2 text-xs leading-relaxed text-emerald-900/80">
                  <li>• Low-impact activity on most days</li>
                  <li>• Gentle range-of-motion and strength work</li>
                  <li>• Regular breaks from prolonged sitting</li>
                  <li>• Tracking pain, stiffness and walking distance</li>
                </ul>
              </div>
              <div className="rounded-2xl border border-rose-200 bg-rose-50 p-5">
                <h3 className="flex items-center gap-2 text-sm font-extrabold text-rose-900"><CircleAlert size={17} /> Be cautious with</h3>
                <ul className="mt-3 space-y-2 text-xs leading-relaxed text-rose-900/80">
                  <li>• Sudden increases in running distance or intensity</li>
                  <li>• Deep squats or twisting during a painful flare</li>
                  <li>• Ignoring swelling, locking or giving way</li>
                  <li>• Using pain medication to push through symptoms</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="space-y-6">
            <section className="card p-5 sm:p-6">
              <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Talk to your doctor</p>
              <h2 className="mt-1 text-xl font-extrabold">Book a review if you notice</h2>
              <ul className="mt-4 space-y-3">
                {[
                  "Knee pain on most days for more than two weeks",
                  "Morning stiffness lasting over 20 minutes",
                  "Swelling, warmth, locking or a feeling of giving way",
                  "Increasing difficulty with stairs, chairs or walking",
                  "A new limp or visible change in leg alignment",
                ].map((item) => (
                  <li key={item} className="flex gap-2 text-xs leading-relaxed text-slate-600">
                    <TriangleAlert size={15} className="mt-0.5 shrink-0 text-amber-500" /> {item}
                  </li>
                ))}
              </ul>
              <Link href="/reports" className="btn-secondary mt-5 w-full text-sm"><CalendarCheck2 size={16} /> View my reports</Link>
            </section>

            <section className="card p-5 sm:p-6">
              <Stethoscope size={21} className="text-teal-600" />
              <h2 className="mt-3 text-lg font-extrabold">What a screening score means</h2>
              <p className="mt-2 text-xs leading-relaxed text-slate-500">
                A higher score means more risk markers were present. It is a prompt for a conversation and healthier habits — not proof that osteoarthritis is present.
              </p>
              <div className="mt-4 space-y-2 text-xs font-semibold">
                <div className="flex justify-between rounded-lg bg-emerald-50 px-3 py-2 text-emerald-800"><span>0–29 · Low</span><span>Maintain habits</span></div>
                <div className="flex justify-between rounded-lg bg-amber-50 px-3 py-2 text-amber-800"><span>30–59 · Moderate</span><span>Track & prevent</span></div>
                <div className="flex justify-between rounded-lg bg-rose-50 px-3 py-2 text-rose-800"><span>60–100 · High</span><span>Clinical review</span></div>
              </div>
            </section>

            <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900">
              <b className="flex items-center gap-2"><CircleAlert size={15} /> Important</b>
              <p className="mt-2">Always seek personalised advice from a qualified clinician. New severe pain, fever, a hot swollen joint or an inability to bear weight needs urgent medical attention.</p>
            </section>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
