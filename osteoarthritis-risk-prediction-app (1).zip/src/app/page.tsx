import {
  Activity,
  ArrowRight,
  Bone,
  BrainCircuit,
  ClipboardCheck,
  FileBarChart2,
  FileImage,
  FileVideo2,
  ScanLine,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  Users,
} from "lucide-react";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import { RiskBadge, SectionHeading, StatusPill, TrendSparkline, formatDate } from "@/components/ui";
import { getAssessmentRecords } from "@/lib/data";
import { MODEL_REPORT } from "@/lib/models";
import type { AssessmentRecord } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let records: AssessmentRecord[] = [];
  let loadError = false;
  try {
    records = await getAssessmentRecords();
  } catch (error) {
    console.error("Dashboard data unavailable", error);
    loadError = true;
  }

  const total = records.length;
  const highRisk = records.filter((record) => record.band === "High").length;
  const pending = records.filter((record) => record.doctorStatus === "Pending review").length;
  const avgFlexion = total
    ? Math.round(records.reduce((sum, record) => sum + record.metrics.avgFlexion, 0) / total)
    : 0;
  const counts = {
    Low: records.filter((record) => record.band === "Low").length,
    Moderate: records.filter((record) => record.band === "Moderate").length,
    High: highRisk,
  };
  const trend = [...records].reverse().slice(-8).map((record) => record.score);
  const recent = records.slice(0, 5);
  const attention = records.filter((record) => record.band === "High" || record.doctorStatus === "Pending review").slice(0, 3);

  const stats = [
    { label: "Total screenings", value: total, detail: "Saved gait assessments", icon: Users, color: "text-teal-600 bg-teal-50" },
    { label: "Elevated risk", value: highRisk, detail: "Need clinical review", icon: ShieldAlert, color: "text-rose-600 bg-rose-50" },
    { label: "Avg. knee flexion", value: `${avgFlexion}°`, detail: "Across annotated frames", icon: Bone, color: "text-indigo-600 bg-indigo-50" },
    { label: "Pending reviews", value: pending, detail: "Awaiting doctor sign-off", icon: ClipboardCheck, color: "text-amber-600 bg-amber-50" },
  ];

  return (
    <AppShell>
      <div className="space-y-6">
        {loadError && (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            Assessment data is temporarily unavailable. The workspace is still available for a new screening.
          </div>
        )}

        <section className="hero-glow bg-grid relative overflow-hidden rounded-3xl text-white shadow-xl shadow-slate-900/10">
          <div className="grid items-center gap-8 px-6 py-8 sm:px-9 lg:grid-cols-[1.25fr_0.75fr] lg:py-10">
            <div className="relative z-10">
              <span className="chip bg-white/12 text-teal-100 ring-1 ring-white/20">
                <Sparkles size={13} /> Early osteoarthritis screening
              </span>
              <h1 className="mt-5 max-w-2xl text-[2.2rem] font-extrabold leading-[1.08] tracking-tight sm:text-[3.1rem]">
                See small gait changes before knee damage progresses.
              </h1>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-teal-50/80 sm:text-base">
                StrideCare turns a walking photo or video into measurable knee flexion, symmetry and alignment markers — then gives doctors and patients a clear, trackable risk signal.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Link href="/assess" className="btn-primary !bg-white !text-[#0b5f61] !shadow-none hover:!bg-teal-50">
                  <ScanLine size={18} /> Start new assessment
                </Link>
                <Link href="/guide" className="btn-secondary !border-white/25 !bg-white/10 !text-white hover:!bg-white/16">
                  Patient prevention guide <ArrowRight size={16} />
                </Link>
              </div>
            </div>
            <div className="relative mx-auto hidden w-full max-w-sm lg:block">
              <div className="overflow-hidden rounded-3xl border border-white/25 bg-white/10 p-2 shadow-2xl backdrop-blur-sm">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/images/sample-gait.jpg" alt="Side-view walking frame" className="aspect-[4/3] w-full rounded-2xl object-cover" />
                <div className="absolute -bottom-4 -left-5 rounded-2xl border border-white/20 bg-[#0a2238]/92 px-4 py-3 shadow-xl">
                  <p className="text-[0.62rem] font-bold uppercase tracking-[0.14em] text-teal-300">Live knee angle</p>
                  <p className="mt-1 text-2xl font-extrabold">34.8° <span className="text-xs font-semibold text-slate-400">flexion</span></p>
                </div>
                <div className="absolute -right-4 top-8 rounded-2xl border border-white/20 bg-white/95 px-4 py-3 text-[#102a43] shadow-xl">
                  <p className="text-[0.62rem] font-bold uppercase tracking-[0.14em] text-slate-400">Keypoints</p>
                  <p className="mt-1 flex items-center gap-2 text-lg font-extrabold"><span className="h-2.5 w-2.5 rounded-full bg-teal-500" /> 6 / 6 <span className="text-xs font-semibold text-emerald-600">mapped</span></p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="card flex items-start justify-between p-5">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-slate-400">{item.label}</p>
                  <p className="mt-2 text-3xl font-extrabold tracking-tight">{item.value}</p>
                  <p className="mt-1 text-xs text-slate-500">{item.detail}</p>
                </div>
                <span className={`grid h-11 w-11 place-items-center rounded-xl ${item.color}`}><Icon size={20} /></span>
              </div>
            );
          })}
        </section>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.65fr)_minmax(300px,0.7fr)]">
          <div className="space-y-6">
            <section className="card p-5 sm:p-6">
              <SectionHeading
                eyebrow="Recent activity"
                title="Latest assessments"
                description="Open any case to review landmarks, angles and the doctor / patient summary."
                action={<Link href="/reports" className="btn-secondary text-xs">All reports <ArrowRight size={14} /></Link>}
              />
              <div className="overflow-x-auto">
                <table className="w-full min-w-[700px] text-left">
                  <thead>
                    <tr className="border-b border-slate-100 text-[0.68rem] font-extrabold uppercase tracking-wider text-slate-400">
                      <th className="pb-3">Patient</th><th className="pb-3">Media</th><th className="pb-3">Knee flexion</th><th className="pb-3">Score</th><th className="pb-3">Status</th><th className="pb-3">Date</th><th className="pb-3" />
                    </tr>
                  </thead>
                  <tbody>
                    {recent.map((record) => (
                      <tr key={record.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/70">
                        <td className="py-3.5">
                          <p className="text-sm font-bold">{record.patient.name}</p>
                          <p className="text-xs text-slate-400">{record.patient.age} yrs · {record.patient.sex}</p>
                        </td>
                        <td className="py-3.5 text-xs font-semibold capitalize text-slate-500">
                          <span className="inline-flex items-center gap-1.5">
                            {record.media.type === "video" ? <FileVideo2 size={14} /> : <FileImage size={14} />}
                            {record.media.type}
                          </span>
                        </td>
                        <td className="py-3.5 text-sm font-bold">{record.metrics.avgFlexion.toFixed(1)}°</td>
                        <td className="py-3.5">
                          <div className="flex items-center gap-2">
                            <span className="w-7 text-sm font-extrabold">{record.score}</span>
                            <div className="h-1.5 w-14 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${record.band === "High" ? "bg-rose-500" : record.band === "Moderate" ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${record.score}%` }} /></div>
                          </div>
                        </td>
                        <td className="py-3.5"><StatusPill status={record.doctorStatus} /></td>
                        <td className="py-3.5 text-xs font-semibold text-slate-500">{formatDate(record.createdAt)}</td>
                        <td className="py-3.5 text-right"><Link href={`/reports/${record.id}`} className="text-teal-700 hover:text-teal-900"><ArrowRight size={17} /></Link></td>
                      </tr>
                    ))}
                    {!recent.length && <tr><td colSpan={7} className="py-8 text-center text-sm text-slate-500">No assessments yet. Start with a walking photo or video.</td></tr>}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="grid gap-6 lg:grid-cols-2">
              <div className="card p-5 sm:p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[0.68rem] font-extrabold uppercase tracking-wider text-teal-700">Score trend</p>
                    <h3 className="mt-1 text-lg font-extrabold">Recent risk scores</h3>
                  </div>
                  <TrendingDown size={20} className="text-teal-600" />
                </div>
                <div className="mt-5"><TrendSparkline values={trend} /></div>
                <div className="mt-2 flex justify-between text-xs font-semibold text-slate-400"><span>Earlier</span><span>Most recent</span></div>
              </div>
              <div className="card p-5 sm:p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[0.68rem] font-extrabold uppercase tracking-wider text-teal-700">Workflow</p>
                    <h3 className="mt-1 text-lg font-extrabold">From pixels to prevention</h3>
                  </div>
                  <Activity size={20} className="text-teal-600" />
                </div>
                <ol className="mt-5 space-y-3">
                  {[
                    { n: "01", title: "Capture", text: "Upload a side-view photo or sample a walking video." },
                    { n: "02", title: "Measure", text: "Use the local landmark model or mark hips, knees and ankles manually." },
                    { n: "03", title: "Act", text: "Save a risk score with tailored doctor and patient guidance." },
                  ].map((item) => (
                    <li key={item.n} className="flex gap-3">
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-teal-50 text-xs font-extrabold text-teal-700">{item.n}</span>
                      <span><b className="block text-sm">{item.title}</b><span className="text-xs text-slate-500">{item.text}</span></span>
                    </li>
                  ))}
                </ol>
              </div>
            </section>
          </div>

          <div className="space-y-6">
            <section className="card p-5 sm:p-6">
              <SectionHeading eyebrow="Population view" title="Risk distribution" />
              <div className="flex h-3 overflow-hidden rounded-full bg-slate-100">
                <div className="bg-emerald-500 transition-all" style={{ width: `${total ? (counts.Low / total) * 100 : 0}%` }} />
                <div className="bg-amber-500 transition-all" style={{ width: `${total ? (counts.Moderate / total) * 100 : 0}%` }} />
                <div className="bg-rose-500 transition-all" style={{ width: `${total ? (counts.High / total) * 100 : 0}%` }} />
              </div>
              <div className="mt-5 space-y-3">
                {(["Low", "Moderate", "High"] as const).map((band) => (
                  <div key={band} className="flex items-center justify-between">
                    <RiskBadge band={band} compact />
                    <span className="text-sm font-extrabold">{counts[band]} <span className="text-xs font-semibold text-slate-400">cases</span></span>
                  </div>
                ))}
              </div>
              <p className="mt-5 rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-500">
                Scores come from the locally trained logistic model using one annotated frame plus intake factors. Track repeated assessments rather than interpreting one score in isolation.
              </p>
            </section>

            <section className="card p-5 sm:p-6">
              <SectionHeading eyebrow="Priority queue" title="Needs attention" />
              <div className="space-y-3">
                {attention.map((record) => (
                  <Link key={record.id} href={`/reports/${record.id}`} className="block rounded-xl border border-slate-200 p-3 transition hover:border-teal-300 hover:bg-teal-50/40">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-bold">{record.patient.name}</p>
                      <span className={`text-lg font-extrabold ${record.band === "High" ? "text-rose-600" : "text-amber-600"}`}>{record.score}</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-2">
                      <StatusPill status={record.doctorStatus} />
                      <span className="text-xs text-slate-400">{formatDate(record.createdAt)}</span>
                    </div>
                  </Link>
                ))}
                {!attention.length && <p className="text-sm text-slate-500">No pending or elevated-risk cases right now.</p>}
              </div>
            </section>

            <section className="card p-5 sm:p-6">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.16em] text-teal-700">Transparent ML</p>
                  <h3 className="mt-1 text-lg font-extrabold">Local model lab</h3>
                </div>
                <BrainCircuit size={21} className="text-teal-600" />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                <div className="rounded-xl bg-slate-50 p-3">
                  <p className="text-xl font-extrabold">{(MODEL_REPORT.risk.accuracy * 100).toFixed(0)}%</p>
                  <p className="text-[0.62rem] font-bold uppercase tracking-wide text-slate-400">Test accuracy</p>
                </div>
                <div className="rounded-xl bg-slate-50 p-3">
                  <p className="text-xl font-extrabold">{MODEL_REPORT.landmarks.meanPixelError.toFixed(1)} px</p>
                  <p className="text-[0.62rem] font-bold uppercase tracking-wide text-slate-400">Landmark error</p>
                </div>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-slate-500">Retrain and retest both models in the browser. No external AI API or pretrained weights.</p>
              <Link href="/models" className="mt-4 inline-flex items-center gap-2 text-sm font-extrabold text-teal-700">Open model lab <ArrowRight size={15} /></Link>
            </section>

            <section className="rounded-2xl border border-teal-200 bg-teal-50 p-5">
              <FileBarChart2 size={22} className="text-teal-700" />
              <h3 className="mt-3 text-base font-extrabold text-[#0b4b4d]">Built for shared decisions</h3>
              <p className="mt-2 text-sm leading-relaxed text-teal-900/75">
                Doctors get landmark-level measurements and review notes. Patients get plain-language cautions, a prevention plan and their clinician’s guidance.
              </p>
              <Link href="/assess" className="mt-4 inline-flex items-center gap-2 text-sm font-extrabold text-teal-800">
                Create an assessment <ArrowRight size={16} />
              </Link>
            </section>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
