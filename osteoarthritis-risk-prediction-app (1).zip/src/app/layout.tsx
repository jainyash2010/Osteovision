import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "StrideCare | Gait & Knee Osteoarthritis Screening",
  description:
    "Clinical gait screening with locally trained landmark and risk models, photo/video keypoints, knee flexion angles, and early osteoarthritis support for doctors and patients.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
