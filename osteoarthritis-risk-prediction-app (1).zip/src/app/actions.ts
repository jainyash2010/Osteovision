"use server";

import { revalidatePath } from "next/cache";
import { createAssessment, updateAssessmentReview } from "@/lib/data";
import { parseAssessmentPayload } from "@/lib/payload";
import type { AssessmentPayload, AssessmentRecord, DoctorStatus } from "@/lib/types";

const statuses: DoctorStatus[] = ["Pending review", "Reviewed", "Follow-up"];

export async function saveAssessment(input: AssessmentPayload): Promise<AssessmentRecord> {
  const payload = parseAssessmentPayload(input);
  const record = await createAssessment(payload);
  revalidatePath("/");
  revalidatePath("/reports");
  return record;
}

export async function reviewAssessment(
  id: number,
  status: DoctorStatus,
  notes: string,
): Promise<AssessmentRecord> {
  if (!Number.isInteger(id) || id <= 0) throw new Error("Invalid report id");
  if (!statuses.includes(status)) throw new Error("Invalid review status");
  const record = await updateAssessmentReview(id, status, notes.slice(0, 2000));
  if (!record) throw new Error("Report not found");
  revalidatePath("/");
  revalidatePath("/reports");
  revalidatePath(`/reports/${id}`);
  return record;
}
