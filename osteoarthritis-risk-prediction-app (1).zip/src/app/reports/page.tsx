import AppShell from "@/components/AppShell";
import ReportsTable, { type ReportRow } from "@/components/ReportsTable";
import { getAssessmentRecords } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata = { title: "Assessment reports | StrideCare" };

export default async function ReportsPage() {
  let rows: ReportRow[] = [];
  try {
    const records = await getAssessmentRecords();
    rows = records.map((record) => ({
      id: record.id,
      patientName: record.patient.name,
      age: record.patient.age,
      sex: record.patient.sex,
      score: record.score,
      band: record.band,
      doctorStatus: record.doctorStatus,
      createdAt: record.createdAt,
      mediaType: record.media.type,
      fileName: record.media.fileName,
      avgFlexion: record.metrics.avgFlexion,
      asymmetry: record.metrics.asymmetry,
    }));
  } catch (error) {
    console.error("Reports data unavailable", error);
  }

  return (
    <AppShell>
      <ReportsTable rows={rows} />
    </AppShell>
  );
}
