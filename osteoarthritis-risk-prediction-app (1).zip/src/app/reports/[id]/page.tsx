import { notFound } from "next/navigation";
import AppShell from "@/components/AppShell";
import ReportView from "@/components/ReportView";
import { getAssessmentRecord } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata = { title: "Assessment report | StrideCare" };

type PageProps = { params: Promise<{ id: string }> };

export default async function ReportDetailPage({ params }: PageProps) {
  const { id } = await params;
  const recordId = Number(id);
  if (!Number.isInteger(recordId) || recordId <= 0) notFound();

  let record = null;
  try {
    record = await getAssessmentRecord(recordId);
  } catch (error) {
    console.error("Unable to load report", error);
  }
  if (!record) notFound();

  return (
    <AppShell>
      <ReportView record={record} />
    </AppShell>
  );
}
