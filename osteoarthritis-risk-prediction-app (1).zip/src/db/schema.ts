import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type {
  ActivityLevel,
  DoctorStatus,
  Keypoints,
  MediaType,
  Metrics,
  RiskBand,
  Sex,
} from "@/lib/types";

export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  sex: text("sex").$type<Sex>().notNull(),
  heightCm: real("height_cm").notNull(),
  weightKg: real("weight_kg").notNull(),
  painLevel: integer("pain_level").notNull(),
  morningStiffness: boolean("morning_stiffness").notNull().default(false),
  priorInjury: boolean("prior_injury").notNull().default(false),
  familyHistory: boolean("family_history").notNull().default(false),
  activityLevel: text("activity_level").$type<ActivityLevel>().notNull(),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id")
    .notNull()
    .references(() => patients.id, { onDelete: "cascade" }),
  mediaType: text("media_type").$type<MediaType>().notNull(),
  fileName: text("file_name").notNull(),
  durationSec: real("duration_sec"),
  aspectRatio: real("aspect_ratio").notNull().default(1.5),
  frames: jsonb("frames").$type<string[]>().notNull(),
  selectedFrame: integer("selected_frame").notNull().default(0),
  keypoints: jsonb("keypoints").$type<Keypoints>().notNull(),
  metrics: jsonb("metrics").$type<Metrics>().notNull(),
  score: integer("score").notNull(),
  band: text("band").$type<RiskBand>().notNull(),
  bmi: real("bmi").notNull(),
  drivers: jsonb("drivers").$type<string[]>().notNull(),
  recommendations: jsonb("recommendations").$type<string[]>().notNull(),
  doctorStatus: text("doctor_status")
    .$type<DoctorStatus>()
    .notNull()
    .default("Pending review"),
  doctorNotes: text("doctor_notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
});
